import React, { useEffect, useState } from 'react';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { LESSONS, type Lesson } from './src/content/lessons';
import { buildLesson, buildReview, type Script } from './src/engine/script';
import { initVoices, type VoiceInfo } from './src/engine/tts';
import { StoreProvider, useStore } from './src/store';
import { HomeScreen } from './src/screens/Home';
import { PlayerScreen } from './src/screens/Player';
import { ProgressScreen } from './src/screens/Progress';
import { CardsScreen } from './src/screens/Cards';
import { C } from './src/theme';

type Session = { title: string; subtitle: string; lessonId: string | null; script: Script };

function Main() {
  const { data, ready, updateSettings } = useStore();
  const [tab, setTab] = useState<'lessons' | 'cards' | 'progress'>('lessons');
  const [session, setSession] = useState<Session | null>(null);
  const [voices, setVoices] = useState<{ ja: VoiceInfo[]; en: VoiceInfo[]; chosen: Partial<Record<'en' | 'A' | 'B', VoiceInfo>>; checked: boolean }>({ ja: [], en: [], chosen: {}, checked: false });

  useEffect(() => {
    if (!ready) return;
    initVoices({ jaA: data.settings.jaA, jaB: data.settings.jaB, en: data.settings.enVoice }).then((r) =>
      setVoices({ ja: r.ja, en: r.en, chosen: { ...r.chosen }, checked: true }),
    );
  }, [ready, data.settings.jaA, data.settings.jaB, data.settings.enVoice]);

  if (!ready) return <View style={s.root} />;

  const startLesson = (l: Lesson) =>
    setSession({ title: `Lesson ${l.n}`, subtitle: l.title, lessonId: l.id, script: buildLesson(l, data.settings.rate) });
  const startReview = () =>
    setSession({
      title: 'Quick review',
      subtitle: 'Review',
      lessonId: null,
      script: buildReview(LESSONS.filter((l) => data.completed[l.id]).map((l) => l.id), data.settings.rate),
    });

  if (session) {
    return (
      <View style={s.root}>
        <PlayerScreen {...session} onClose={() => setSession(null)} />
      </View>
    );
  }

  return (
    <View style={s.root}>
      <View style={{ flex: 1 }}>
        {tab === 'lessons' ? (
          <HomeScreen onStart={startLesson} onReview={startReview} noVoice={voices.checked && voices.ja.length === 0} />
        ) : tab === 'cards' ? (
          <CardsScreen />
        ) : (
          <ProgressScreen
            jaVoices={voices.ja}
            enVoices={voices.en}
            chosen={voices.chosen}
            onVoice={(role, id) =>
              updateSettings(role === 'en' ? { enVoice: id } : role === 'A' ? { jaA: id, jaB: voices.chosen.B?.id } : { jaA: voices.chosen.A?.id, jaB: id })
            }
          />
        )}
      </View>
      <View style={s.tabs}>
        {(['lessons', 'cards', 'progress'] as const).map((t) => (
          <Pressable key={t} onPress={() => setTab(t)} style={s.tab}>
            <View style={[s.tabDot, tab === t && { backgroundColor: C.accent }]} />
            <Text style={[s.tabText, tab === t && { color: C.text }]}>{t === 'lessons' ? 'Lessons' : t === 'cards' ? 'Flashcards' : 'Progress'}</Text>
          </Pressable>
        ))}
      </View>
    </View>
  );
}

export default function App() {
  return (
    <StoreProvider>
      <StatusBar style="light" />
      <Main />
    </StoreProvider>
  );
}

const s = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: C.bg,
    paddingTop: Platform.OS === 'web' ? 0 : 48,
    ...(Platform.OS === 'web' ? ({ minHeight: '100%' } as object) : null),
  },
  tabs: {
    flexDirection: 'row',
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: C.line,
    backgroundColor: C.bg,
    paddingBottom: Platform.OS === 'web' ? 18 : 28,
    paddingTop: 10,
  },
  tab: { flex: 1, alignItems: 'center', gap: 5 },
  tabDot: { width: 5, height: 5, borderRadius: 3, backgroundColor: 'transparent' },
  tabText: { color: C.faint, fontSize: 12, fontWeight: '600', letterSpacing: 0.6 },
});

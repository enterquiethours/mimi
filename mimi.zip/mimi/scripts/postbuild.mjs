// Makes the web export work from any sub-folder (GitHub Pages serves from
// /<repo>/) and adds what iOS needs to install it on the home screen.
import fs from 'node:fs';
import path from 'node:path';

const dist = path.resolve(process.argv[2] ?? 'dist');
const file = path.join(dist, 'index.html');
let html = fs.readFileSync(file, 'utf8');

// absolute asset paths -> relative
html = html.replace(/(src|href)="\/(?!\/)/g, '$1="./');

const head = `
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover, user-scalable=no" />
    <meta name="theme-color" content="#0E0F13" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black" />
    <meta name="apple-mobile-web-app-title" content="mimi" />
    <link rel="manifest" href="./manifest.json" />
    <link rel="apple-touch-icon" href="./apple-touch-icon.png" />
    <style>
      html, body { background: #0E0F13; overscroll-behavior: none; }
      body { padding-top: env(safe-area-inset-top); padding-bottom: env(safe-area-inset-bottom); box-sizing: border-box; }
    </style>
    <script>
      if ('serviceWorker' in navigator && location.protocol === 'https:') {
        window.addEventListener('load', () => navigator.serviceWorker.register('./sw.js').catch(() => {}));
      }
    </script>`;
html = html.replace(/<meta name="viewport"[^>]*>/, '');
html = html.replace('</head>', head + '\n  </head>');
html = html.replace(/<title>.*?<\/title>/, '<title>mimi · Japanese by ear</title>');
fs.writeFileSync(file, html);
fs.writeFileSync(path.join(dist, '.nojekyll'), '');
console.log('postbuild: patched', file);

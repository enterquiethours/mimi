import React from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { LESSONS, type Lesson } from '../content/lessons';
import { DAILY_GOAL_SEC, dayKey, streaks, useStore } from '../store';
import { C } from '../theme';
import { Check, Flame, Play } from '../components/Icons';
import { Ring } from '../components/Ring';

type Props = { onStart: (lesson: Lesson) => void; onReview: () => void; noVoice: boolean };

export function HomeScreen({ onStart, onReview, noVoice }: Props) {
  const { data } = useStore();
  const { current } = streaks(data);
  const todaySec = data.days[dayKey()] ?? 0;
  const next = LESSONS.find((l) => !data.completed[l.id]) ?? LESSONS[LESSONS.length - 1];
  const resumeAt = data.positions[next.id] ?? 0;
  const doneCount = Object.keys(data.completed).length;
  const allDone = doneCount === LESSONS.length;

  return (
    <ScrollView style={{ flex: 1 }} contentContainerStyle={s.wrap}>
      <View style={s.header}>
        <View>
          <Text style={s.brand}>mimi</Text>
          <Text style={s.brandSub}>Japanese by ear · 耳</Text>
        </View>
        <View style={s.today}>
          <View style={{ width: 44, height: 44, alignItems: 'center', justifyContent: 'center' }}>
            <Ring size={44} stroke={4} progress={todaySec / DAILY_GOAL_SEC} color={C.gold} />
            <Flame size={18} color={current > 0 ? C.gold : C.faint} />
          </View>
          <View>
            <Text style={s.streakNum}>{current}</Text>
            <Text style={s.streakLabel}>day streak</Text>
          </View>
        </View>
      </View>

      {noVoice ? (
        <View style={s.warn}>
          <Text style={s.warnTitle}>No Japanese voice found</Text>
          <Text style={s.warnText}>
            On iPhone: Settings → Accessibility → Spoken Content → Voices → Japanese, and download Kyoko or Otoya. Then reopen the app.
          </Text>
        </View>
      ) : null}

      <Pressable onPress={() => onStart(next)} style={({ pressed }) => [s.hero, pressed && { opacity: 0.9 }]}>
        <Text style={s.heroKicker}>{allDone ? 'Replay' : resumeAt > 0 ? 'Continue' : 'Up next'}</Text>
        <Text style={s.heroNum}>Lesson {next.n}</Text>
        <Text style={s.heroTitle}>{next.title}</Text>
        <Text style={s.heroJp}>{next.jp}</Text>
        <View style={s.heroRow}>
          <Text style={s.heroMeta}>About 30 min · audio</Text>
          <View style={s.heroPlay}>
            <Play size={26} color={C.bg} />
          </View>
        </View>
      </Pressable>

      <Pressable
        disabled={doneCount === 0}
        onPress={onReview}
        style={({ pressed }) => [s.review, doneCount === 0 && { opacity: 0.4 }, pressed && { opacity: 0.8 }]}
      >
        <View>
          <Text style={s.reviewTitle}>Quick review</Text>
          <Text style={s.reviewSub}>{doneCount === 0 ? 'Unlocks after lesson 1' : '10 min · everything so far'}</Text>
        </View>
        <Play size={18} color={C.text} />
      </Pressable>

      <Text style={s.sectionTitle}>Lessons</Text>
      {LESSONS.map((l) => {
        const done = !!data.completed[l.id];
        const isNext = l.id === next.id && !allDone;
        return (
          <Pressable key={l.id} onPress={() => onStart(l)} style={({ pressed }) => [s.row, pressed && { backgroundColor: C.surface }]}>
            <View style={[s.num, done && s.numDone, isNext && s.numNext]}>
              {done ? <Check size={16} /> : <Text style={[s.numText, isNext && { color: C.accent }]}>{l.n}</Text>}
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[s.rowTitle, !done && !isNext && { color: C.muted }]}>{l.title}</Text>
              <Text style={s.rowJp}>{l.jp}</Text>
            </View>
          </Pressable>
        );
      })}
      <Text style={s.footer}>One lesson a day. Say everything out loud.</Text>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  wrap: { padding: 20, paddingTop: 16, paddingBottom: 40, maxWidth: 560, width: '100%', alignSelf: 'center' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 22 },
  brand: { color: C.text, fontSize: 30, fontWeight: '700', letterSpacing: -0.5 },
  brandSub: { color: C.muted, fontSize: 13, marginTop: 2 },
  today: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  streakNum: { color: C.text, fontSize: 20, fontWeight: '700' },
  streakLabel: { color: C.muted, fontSize: 11, marginTop: -2 },
  warn: { backgroundColor: C.accentSoft, borderRadius: 14, padding: 14, marginBottom: 16 },
  warnTitle: { color: C.text, fontWeight: '600', marginBottom: 4 },
  warnText: { color: C.muted, fontSize: 13, lineHeight: 19 },
  hero: { backgroundColor: C.accent, borderRadius: 24, padding: 22, marginBottom: 12 },
  heroKicker: { color: 'rgba(14,15,19,0.6)', fontSize: 12, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 1.4 },
  heroNum: { color: C.bg, fontSize: 15, fontWeight: '600', marginTop: 14 },
  heroTitle: { color: C.bg, fontSize: 30, fontWeight: '700', letterSpacing: -0.5, marginTop: 2 },
  heroJp: { color: 'rgba(14,15,19,0.7)', fontSize: 17, marginTop: 4 },
  heroRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 22 },
  heroMeta: { color: 'rgba(14,15,19,0.65)', fontSize: 13, fontWeight: '500' },
  heroPlay: { width: 54, height: 54, borderRadius: 27, backgroundColor: C.text, alignItems: 'center', justifyContent: 'center', paddingLeft: 4 },
  review: { backgroundColor: C.surface, borderRadius: 18, padding: 18, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 28 },
  reviewTitle: { color: C.text, fontSize: 16, fontWeight: '600' },
  reviewSub: { color: C.muted, fontSize: 13, marginTop: 2 },
  sectionTitle: { color: C.muted, fontSize: 12, fontWeight: '600', textTransform: 'uppercase', letterSpacing: 1.4, marginBottom: 6 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 14, paddingVertical: 12, paddingHorizontal: 6, borderRadius: 12 },
  num: { width: 36, height: 36, borderRadius: 18, borderWidth: 1.5, borderColor: C.line, alignItems: 'center', justifyContent: 'center' },
  numDone: { backgroundColor: C.green, borderColor: C.green },
  numNext: { borderColor: C.accent },
  numText: { color: C.muted, fontWeight: '600' },
  rowTitle: { color: C.text, fontSize: 16, fontWeight: '500' },
  rowJp: { color: C.faint, fontSize: 13, marginTop: 2 },
  footer: { color: C.faint, fontSize: 12, textAlign: 'center', marginTop: 24 },
});

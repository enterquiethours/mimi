import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Animated, Easing, Pressable, StyleSheet, Text, View } from 'react-native';
import { activateKeepAwakeAsync, deactivateKeepAwake } from 'expo-keep-awake';
import { LessonPlayer, type PlayerState } from '../engine/player';
import type { Cue, Script } from '../engine/script';
import { useStore } from '../store';
import { C } from '../theme';
import { Back, Close, Forward, Pause, Play, Text as TextIcon } from '../components/Icons';
import { Ring } from '../components/Ring';

type Props = {
  title: string;
  subtitle: string;
  lessonId: string | null; // null = review session
  script: Script;
  onClose: () => void;
};

const PHASE_LABEL: Record<string, string> = {
  listen: 'Listen',
  repeat: 'Repeat',
  answer: 'Your turn',
  narrator: '',
};

function fmt(sec: number) {
  const s = Math.max(0, Math.round(sec));
  return `${Math.floor(s / 60)}:${`${s % 60}`.padStart(2, '0')}`;
}

/** What to show on screen for a cue, without giving away answers. */
function display(cues: Cue[], i: number): { ja?: string; ro?: string; en?: string; hint?: string } {
  const c = cues[i];
  if (!c) return {};
  if (c.kind === 'ja') return { ja: c.text, ro: c.ro, en: c.en };
  if (c.kind === 'pause') {
    if (c.phase === 'answer') return { hint: 'Say it out loud' };
    return { ja: c.ja, ro: c.ro };
  }
  return { hint: c.text };
}

export function PlayerScreen({ title, subtitle, lessonId, script, onClose }: Props) {
  const { data, addSeconds, complete, savePosition, updateSettings } = useStore();
  const { settings } = data;
  const startAt = lessonId ? data.positions[lessonId] ?? 0 : 0;

  const player = useMemo(
    () =>
      new LessonPlayer(script, { rate: settings.rate, pauseScale: settings.pauseScale }, startAt, () => {
        if (lessonId) complete(lessonId);
      }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [script],
  );
  const [st, setSt] = useState<PlayerState>(player.state);
  useEffect(() => player.subscribe(setSt), [player]);
  useEffect(() => () => player.destroy(), [player]);

  // keep the settings live
  useEffect(() => {
    player.settings = { rate: settings.rate, pauseScale: settings.pauseScale };
  }, [player, settings.rate, settings.pauseScale]);

  // cumulative time for progress
  const cum = useMemo(() => {
    const out: number[] = [];
    let t = 0;
    for (const c of script.cues) {
      out.push(t);
      t += c.est + 0.28;
    }
    return out;
  }, [script]);

  // practice time tracking + keep screen awake while playing
  const pending = useRef(0);
  useEffect(() => {
    if (!st.playing) return;
    activateKeepAwakeAsync('lesson').catch(() => {});
    const t = setInterval(() => {
      pending.current += 1;
      if (pending.current >= 15) {
        addSeconds(pending.current);
        pending.current = 0;
      }
    }, 1000);
    return () => {
      clearInterval(t);
      try {
        deactivateKeepAwake('lesson');
      } catch {}
      if (pending.current) {
        addSeconds(pending.current);
        pending.current = 0;
      }
    };
  }, [st.playing, addSeconds]);

  // remember where you are
  const lastSaved = useRef(startAt);
  useEffect(() => {
    if (!lessonId || st.done) return;
    if (!st.playing || Math.abs(st.index - lastSaved.current) > 20) {
      lastSaved.current = st.index;
      savePosition(lessonId, st.index);
    }
  }, [st.index, st.playing, st.done, lessonId, savePosition]);

  // countdown bar for pauses
  const bar = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    bar.stopAnimation();
    if (st.pauseStartedAt && st.playing) {
      bar.setValue(1);
      Animated.timing(bar, { toValue: 0, duration: st.pauseLength, easing: Easing.linear, useNativeDriver: false }).start();
    } else {
      bar.setValue(0);
    }
  }, [st.pauseStartedAt, st.playing, st.pauseLength, bar]);

  const cue = script.cues[st.index];
  const phase = cue?.phase ?? 'narrator';
  const show = display(script.cues, st.index);
  const elapsed = cum[st.index] ?? 0;
  const progress = st.done ? 1 : elapsed / script.totalSec;

  const label = st.done ? 'Complete' : !st.playing ? (st.index === 0 ? 'Tap to begin' : 'Paused') : PHASE_LABEL[phase];

  return (
    <View style={s.root}>
      <View style={s.top}>
        <Pressable hitSlop={12} onPress={() => { player.pause(); onClose(); }} style={s.iconBtn} accessibilityLabel="Close lesson">
          <Close />
        </Pressable>
        <View style={{ alignItems: 'center' }}>
          <Text style={s.topTitle}>{title}</Text>
          <Text style={s.topSub}>{cue?.section ?? subtitle}</Text>
        </View>
        <Pressable hitSlop={12} onPress={() => updateSettings({ showText: !settings.showText })} style={[s.iconBtn, settings.showText && s.iconOn]} accessibilityLabel="Show text">
          <TextIcon color={settings.showText ? C.text : C.faint} />
        </Pressable>
      </View>

      <View style={s.center}>
        <Pressable onPress={() => player.toggle()} style={s.ringWrap} accessibilityLabel={st.playing ? 'Pause' : 'Play'}>
          <Ring size={232} stroke={5} progress={progress} />
          <View style={[s.playBtn, st.playing && s.playBtnOn]}>
            {st.playing ? <Pause size={40} color={C.text} /> : <Play size={44} color={C.bg} />}
          </View>
        </Pressable>

        <Text style={[s.phase, phase === 'answer' && st.playing && { color: C.accent }]}>{label}</Text>
        <View style={s.barTrack}>
          <Animated.View style={[s.bar, { width: bar.interpolate({ inputRange: [0, 1], outputRange: ['0%', '100%'] }) }]} />
        </View>

        <View style={s.textArea}>
          {settings.showText && show.ja ? (
            <>
              <Text style={s.ja}>{show.ja}</Text>
              <Text style={s.ro}>{show.ro}</Text>
              {show.en ? <Text style={s.en}>{show.en}</Text> : null}
            </>
          ) : show.hint && st.playing ? (
            <Text style={s.hint} numberOfLines={4}>{show.hint}</Text>
          ) : null}
        </View>
      </View>

      <View style={s.controls}>
        <Text style={s.time}>{fmt(elapsed)}</Text>
        <View style={s.ctrlRow}>
          <Pressable hitSlop={10} onPress={() => player.back()} style={s.ctrl} accessibilityLabel="Back one exercise">
            <Back />
            <Text style={s.ctrlLabel}>Back</Text>
          </Pressable>
          <Pressable hitSlop={10} onPress={() => player.forward()} style={s.ctrl} accessibilityLabel="Skip exercise">
            <Forward />
            <Text style={s.ctrlLabel}>Skip</Text>
          </Pressable>
        </View>
        <Text style={s.time}>{fmt(script.totalSec)}</Text>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg, paddingTop: 12, paddingBottom: 28 },
  top: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 18 },
  iconBtn: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  iconOn: { backgroundColor: C.surface2 },
  topTitle: { color: C.text, fontSize: 15, fontWeight: '600' },
  topSub: { color: C.muted, fontSize: 12, marginTop: 2, textTransform: 'uppercase', letterSpacing: 1.4 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 24 },
  ringWrap: { width: 232, height: 232, alignItems: 'center', justifyContent: 'center' },
  playBtn: { width: 120, height: 120, borderRadius: 60, backgroundColor: C.accent, alignItems: 'center', justifyContent: 'center', paddingLeft: 6 },
  playBtnOn: { backgroundColor: C.surface2, paddingLeft: 0 },
  phase: { color: C.text, fontSize: 22, fontWeight: '600', marginTop: 34, minHeight: 28, letterSpacing: 0.3 },
  barTrack: { width: 120, height: 3, borderRadius: 2, backgroundColor: 'transparent', marginTop: 12, overflow: 'hidden' },
  bar: { height: 3, backgroundColor: C.accent, borderRadius: 2 },
  textArea: { minHeight: 150, marginTop: 26, alignItems: 'center', justifyContent: 'flex-start', width: '100%', maxWidth: 420 },
  ja: { color: C.text, fontSize: 30, fontWeight: '600', textAlign: 'center', letterSpacing: 1, lineHeight: 42 },
  ro: { color: C.muted, fontSize: 16, marginTop: 8, textAlign: 'center' },
  en: { color: C.faint, fontSize: 14, marginTop: 6, textAlign: 'center', fontStyle: 'italic' },
  hint: { color: C.muted, fontSize: 16, textAlign: 'center', lineHeight: 23 },
  controls: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 28 },
  ctrlRow: { flexDirection: 'row', gap: 44 },
  ctrl: { alignItems: 'center', gap: 4 },
  ctrlLabel: { color: C.muted, fontSize: 11, letterSpacing: 0.8, textTransform: 'uppercase' },
  time: { color: C.faint, fontSize: 13, width: 44, fontVariant: ['tabular-nums'] },
});

import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { LESSONS, type Item, type Lesson } from '../content/lessons';
import { speakable } from '../engine/kana';
import * as tts from '../engine/tts';
import { dayKey, useStore } from '../store';
import { C } from '../theme';
import { Play } from '../components/Icons';

type Card = { key: string; item: Item; lesson: Lesson };
type Dir = 'ja-en' | 'en-ja';

const SESSION = 20;
const cardKey = (l: Lesson, i: Item) => `${l.id}:${i.id}`;

function Speaker({ onPress, light }: { onPress: () => void; light?: boolean }) {
  return (
    <Pressable onPress={onPress} hitSlop={12} style={[s.speaker, light && { backgroundColor: C.surface2 }]} accessibilityLabel="Hear it">
      <Play size={18} color={C.text} />
      <Text style={s.speakerText}>Hear it</Text>
    </Pressable>
  );
}

export function CardsScreen() {
  const { data, gradeCard, addSeconds } = useStore();
  const learned = LESSONS.filter((l) => data.completed[l.id]);
  const [deck, setDeck] = useState<string>('learned'); // 'learned' or a lesson id
  const [dir, setDir] = useState<Dir>('ja-en');
  const [queue, setQueue] = useState<Card[] | null>(null);
  const [flipped, setFlipped] = useState(false);
  const [stats, setStats] = useState({ first: 0, total: 0 });
  const missed = useRef(new Set<string>());

  const deckLessons = deck === 'learned' ? (learned.length ? learned : LESSONS.slice(0, 1)) : LESSONS.filter((l) => l.id === deck);
  const cards: Card[] = useMemo(
    () => deckLessons.flatMap((lesson) => lesson.items.map((item) => ({ key: cardKey(lesson, item), item, lesson }))),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [deck, learned.length],
  );
  const today = dayKey();
  const dueCount = cards.filter((c) => (data.cards[c.key]?.due ?? today) <= today).length;
  const mastered = cards.filter((c) => (data.cards[c.key]?.box ?? 0) >= 3).length;

  // count flashcard practice toward the daily streak
  useEffect(() => {
    if (!queue) return;
    const t = setInterval(() => addSeconds(10), 10000);
    return () => clearInterval(t);
  }, [queue, addSeconds]);

  const say = (item: Item) => {
    tts.stop();
    tts.speak(speakable(item.kana), 'A', { rate: data.settings.rate, onDone: () => {} });
  };

  const start = () => {
    tts.unlock();
    // due and weakest cards first, then a shuffle within the same box
    const sorted = [...cards].sort((a, b) => {
      const A = data.cards[a.key];
      const B = data.cards[b.key];
      const da = A?.due ?? '';
      const db = B?.due ?? '';
      const dueA = da <= today ? 0 : 1;
      const dueB = db <= today ? 0 : 1;
      return dueA - dueB || (A?.box ?? 0) - (B?.box ?? 0) || Math.random() - 0.5;
    });
    const q = sorted.slice(0, SESSION);
    missed.current.clear();
    setStats({ first: 0, total: q.length });
    setFlipped(false);
    setQueue(q);
    if (dir === 'ja-en' && q[0]) say(q[0].item);
  };

  const flip = () => {
    if (!queue?.[0]) return;
    setFlipped(true);
    if (dir === 'en-ja') say(queue[0].item);
  };

  const grade = (knewIt: boolean) => {
    if (!queue) return;
    const [card, ...rest] = queue;
    gradeCard(card.key, knewIt);
    if (knewIt && !missed.current.has(card.key)) setStats((x) => ({ ...x, first: x.first + 1 }));
    let next = rest;
    if (!knewIt) {
      missed.current.add(card.key);
      // bring it back a few cards later
      next = [...rest.slice(0, 3), card, ...rest.slice(3)];
    }
    setFlipped(false);
    setQueue(next);
    if (dir === 'ja-en' && next[0]) say(next[0].item);
  };

  // ---- in a session -------------------------------------------------------
  if (queue) {
    const card = queue[0];
    if (!card) {
      return (
        <View style={s.doneWrap}>
          <Text style={s.doneBig}>{stats.first}/{stats.total}</Text>
          <Text style={s.doneText}>right on the first try</Text>
          <Pressable onPress={start} style={s.primary}>
            <Text style={s.primaryText}>Another round</Text>
          </Pressable>
          <Pressable onPress={() => setQueue(null)} style={s.secondary}>
            <Text style={s.secondaryText}>Done</Text>
          </Pressable>
        </View>
      );
    }
    const { item } = card;
    const showJa = dir === 'ja-en' || flipped;
    const showEn = dir === 'en-ja' || flipped;
    return (
      <View style={s.session}>
        <View style={s.sessionTop}>
          <Pressable onPress={() => { tts.stop(); setQueue(null); }} hitSlop={12}>
            <Text style={s.quit}>End</Text>
          </Pressable>
          <Text style={s.remaining}>{queue.length} left</Text>
        </View>

        <Pressable onPress={flipped ? undefined : flip} style={s.card}>
          <Text style={s.cardLesson}>Lesson {card.lesson.n}</Text>
          <View style={s.cardBody}>
            {showJa ? (
              <>
                <Text style={s.cardJa}>{item.kana.replace(/\s+/g, ' ')}</Text>
                <Text style={s.cardRo}>{item.ro}</Text>
              </>
            ) : null}
            {showJa && showEn ? <View style={s.divider} /> : null}
            {showEn ? <Text style={[s.cardEn, dir === 'en-ja' && !flipped && s.cardEnBig]}>{item.en}</Text> : null}
          </View>
          {showJa ? <Speaker onPress={() => say(item)} light /> : <View style={{ height: 40 }} />}
          {!flipped ? (
            <Text style={s.prompt}>{dir === 'ja-en' ? 'Say what it means, then tap to check' : 'Say it in Japanese, then tap to check'}</Text>
          ) : null}
        </Pressable>

        {flipped ? (
          <View style={s.gradeRow}>
            <Pressable onPress={() => grade(false)} style={[s.grade, s.gradeAgain]}>
              <Text style={s.gradeText}>Not yet</Text>
            </Pressable>
            <Pressable onPress={() => grade(true)} style={[s.grade, s.gradeGot]}>
              <Text style={[s.gradeText, { color: C.bg }]}>Got it</Text>
            </Pressable>
          </View>
        ) : (
          <Pressable onPress={flip} style={[s.grade, s.reveal]}>
            <Text style={s.gradeText}>Show answer</Text>
          </Pressable>
        )}
      </View>
    );
  }

  // ---- deck picker --------------------------------------------------------
  return (
    <ScrollView style={{ flex: 1 }} contentContainerStyle={s.wrap}>
      <Text style={s.h1}>Flashcards</Text>
      <Text style={s.sub}>
        {learned.length ? `Every word and phrase from the ${learned.length === 1 ? 'lesson' : `${learned.length} lessons`} you’ve finished.` : 'Finish lesson 1 to build your deck. Until then, here’s a preview of lesson 1.'}
      </Text>

      <View style={s.chips}>
        <Chip on={deck === 'learned'} label="All learned" onPress={() => setDeck('learned')} />
        {LESSONS.map((l) => (
          <Chip key={l.id} on={deck === l.id} label={`${l.n}`} dim={!data.completed[l.id]} onPress={() => setDeck(l.id)} />
        ))}
      </View>

      <View style={s.statsRow}>
        <Stat n={cards.length} label="cards" />
        <Stat n={dueCount} label="due today" />
        <Stat n={mastered} label="known well" />
      </View>

      <Text style={s.label}>Show me</Text>
      <View style={s.seg}>
        {([['ja-en', 'Japanese → English'], ['en-ja', 'English → Japanese']] as const).map(([v, label]) => (
          <Pressable key={v} onPress={() => setDir(v)} style={[s.segItem, dir === v && s.segOn]}>
            <Text style={[s.segText, dir === v && { color: C.text }]}>{label}</Text>
          </Pressable>
        ))}
      </View>

      <Pressable onPress={start} style={[s.primary, { marginTop: 24 }]}>
        <Text style={s.primaryText}>Start · {Math.min(SESSION, cards.length)} cards</Text>
      </Pressable>

      <Text style={[s.label, { marginTop: 30 }]}>In this deck</Text>
      {cards.map((c) => {
        const box = data.cards[c.key]?.box ?? 0;
        return (
          <Pressable key={c.key} onPress={() => { tts.unlock(); say(c.item); }} style={s.wordRow}>
            <View style={{ flex: 1 }}>
              <Text style={s.wordJa}>{c.item.kana.replace(/\s+/g, ' ')}</Text>
              <Text style={s.wordEn}>{c.item.ro} · {c.item.en}</Text>
            </View>
            <View style={s.boxes}>
              {[1, 2, 3].map((b) => (
                <View key={b} style={[s.boxDot, box >= b && { backgroundColor: C.green }]} />
              ))}
            </View>
          </Pressable>
        );
      })}
      <Text style={s.foot}>Tap any word to hear it. Dots fill in as you get a card right on different days.</Text>
    </ScrollView>
  );
}

function Chip({ label, on, dim, onPress }: { label: string; on: boolean; dim?: boolean; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={[s.chip, on && s.chipOn]}>
      <Text style={[s.chipText, on && { color: C.bg }, dim && !on && { color: C.faint }]}>{label}</Text>
    </Pressable>
  );
}

function Stat({ n, label }: { n: number; label: string }) {
  return (
    <View style={s.stat}>
      <Text style={s.statN}>{n}</Text>
      <Text style={s.statL}>{label}</Text>
    </View>
  );
}

const s = StyleSheet.create({
  wrap: { padding: 20, paddingTop: 16, paddingBottom: 40, maxWidth: 560, width: '100%', alignSelf: 'center' },
  h1: { color: C.text, fontSize: 30, fontWeight: '700', letterSpacing: -0.5 },
  sub: { color: C.muted, fontSize: 14, marginTop: 6, marginBottom: 18, lineHeight: 20 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 16 },
  chip: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 18, backgroundColor: C.surface },
  chipOn: { backgroundColor: C.text },
  chipText: { color: C.text, fontSize: 13, fontWeight: '600' },
  statsRow: { flexDirection: 'row', gap: 10, marginBottom: 20 },
  stat: { flex: 1, backgroundColor: C.surface, borderRadius: 16, padding: 14 },
  statN: { color: C.text, fontSize: 22, fontWeight: '700' },
  statL: { color: C.muted, fontSize: 12, marginTop: 2 },
  label: { color: C.muted, fontSize: 12, fontWeight: '600', textTransform: 'uppercase', letterSpacing: 1.4, marginBottom: 8 },
  seg: { flexDirection: 'row', backgroundColor: C.surface, borderRadius: 12, padding: 3 },
  segItem: { flex: 1, paddingVertical: 10, borderRadius: 10, alignItems: 'center' },
  segOn: { backgroundColor: C.surface2 },
  segText: { color: C.faint, fontSize: 13, fontWeight: '500' },
  primary: { backgroundColor: C.accent, borderRadius: 16, paddingVertical: 16, alignItems: 'center', alignSelf: 'stretch' },
  primaryText: { color: C.bg, fontSize: 16, fontWeight: '700' },
  secondary: { paddingVertical: 16, alignItems: 'center' },
  secondaryText: { color: C.muted, fontSize: 15 },
  wordRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: C.line },
  wordJa: { color: C.text, fontSize: 18, fontWeight: '500' },
  wordEn: { color: C.muted, fontSize: 13, marginTop: 3 },
  boxes: { flexDirection: 'row', gap: 4, marginLeft: 12 },
  boxDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: C.line },
  foot: { color: C.faint, fontSize: 12, marginTop: 16, textAlign: 'center' },

  session: { flex: 1, padding: 20, paddingBottom: 24, maxWidth: 560, width: '100%', alignSelf: 'center' },
  sessionTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  quit: { color: C.muted, fontSize: 15 },
  remaining: { color: C.faint, fontSize: 13 },
  card: { flex: 1, backgroundColor: C.surface, borderRadius: 28, padding: 24, alignItems: 'center', justifyContent: 'space-between' },
  cardLesson: { color: C.faint, fontSize: 12, textTransform: 'uppercase', letterSpacing: 1.4 },
  cardBody: { flex: 1, justifyContent: 'center', alignItems: 'center', width: '100%' },
  cardJa: { color: C.text, fontSize: 34, fontWeight: '600', textAlign: 'center', lineHeight: 46 },
  cardRo: { color: C.muted, fontSize: 17, marginTop: 10, textAlign: 'center' },
  divider: { width: 40, height: 2, backgroundColor: C.line, marginVertical: 22 },
  cardEn: { color: C.text, fontSize: 20, textAlign: 'center', lineHeight: 27 },
  cardEnBig: { fontSize: 28, fontWeight: '600', lineHeight: 36 },
  speaker: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 16, paddingVertical: 10, borderRadius: 20 },
  speakerText: { color: C.text, fontSize: 14, fontWeight: '600' },
  prompt: { color: C.faint, fontSize: 13, marginTop: 14 },
  gradeRow: { flexDirection: 'row', gap: 12, marginTop: 16 },
  grade: { flex: 1, borderRadius: 16, paddingVertical: 17, alignItems: 'center' },
  gradeAgain: { backgroundColor: C.surface2 },
  gradeGot: { backgroundColor: C.green },
  reveal: { backgroundColor: C.surface2, marginTop: 16, flex: 0 },
  gradeText: { color: C.text, fontSize: 16, fontWeight: '700' },
  doneWrap: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 32, maxWidth: 420, width: '100%', alignSelf: 'center' },
  doneBig: { color: C.text, fontSize: 56, fontWeight: '700' },
  doneText: { color: C.muted, fontSize: 15, marginTop: 4, marginBottom: 36 },
});

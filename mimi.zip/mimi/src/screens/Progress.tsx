import React, { useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { LESSONS } from '../content/lessons';
import { DAILY_GOAL_SEC, dayKey, practiced, streaks, useStore } from '../store';
import { preview, unlock, type VoiceInfo } from '../engine/tts';
import { C } from '../theme';
import { Flame } from '../components/Icons';

const WEEKS = 16;

function Heatmap() {
  const { data } = useStore();
  const today = new Date();
  // start on the Monday WEEKS-1 weeks ago
  const start = new Date(today);
  start.setDate(today.getDate() - ((today.getDay() + 6) % 7) - (WEEKS - 1) * 7);
  const cols = [];
  for (let w = 0; w < WEEKS; w++) {
    const cells = [];
    for (let d = 0; d < 7; d++) {
      const day = new Date(start);
      day.setDate(start.getDate() + w * 7 + d);
      const k = dayKey(day);
      const sec = data.days[k] ?? 0;
      const future = day > today;
      const level = future ? -1 : practiced(data, k) ? Math.min(3, 1 + Math.floor(sec / (DAILY_GOAL_SEC / 2))) : 0;
      const bg = level < 0 ? 'transparent' : ['#20232B', 'rgba(228,87,46,0.45)', 'rgba(228,87,46,0.75)', C.accent][level];
      cells.push(<View key={d} style={[s.cell, { backgroundColor: bg }, k === dayKey() && s.cellToday]} />);
    }
    cols.push(<View key={w} style={s.col}>{cells}</View>);
  }
  return (
    <View>
      <View style={s.heat}>{cols}</View>
      <View style={s.legend}>
        <Text style={s.legendText}>{WEEKS} weeks</Text>
        <View style={{ flexDirection: 'row', gap: 4, alignItems: 'center' }}>
          <Text style={s.legendText}>less</Text>
          {['#20232B', 'rgba(228,87,46,0.45)', 'rgba(228,87,46,0.75)', C.accent].map((c) => (
            <View key={c} style={[s.cellSm, { backgroundColor: c }]} />
          ))}
          <Text style={s.legendText}>more</Text>
        </View>
      </View>
    </View>
  );
}

function Seg<T extends string | number>({ value, options, onChange }: { value: T; options: { label: string; value: T }[]; onChange: (v: T) => void }) {
  return (
    <View style={s.seg}>
      {options.map((o) => (
        <Pressable key={String(o.value)} onPress={() => onChange(o.value)} style={[s.segItem, o.value === value && s.segOn]}>
          <Text style={[s.segText, o.value === value && { color: C.text }]}>{o.label}</Text>
        </Pressable>
      ))}
    </View>
  );
}

type Role = 'en' | 'A' | 'B';
type Props = {
  jaVoices: VoiceInfo[];
  enVoices: VoiceInfo[];
  chosen: Partial<Record<Role, VoiceInfo>>;
  onVoice: (role: Role, id: string) => void;
};

const SAMPLE: Record<Role, string> = {
  en: 'Hi Christina. How do you say, excuse me?',
  A: 'はじめまして。クリスティーナです。',
  B: 'こんにちは。よろしくおねがいします。',
};
const ROLE_LABEL: Record<Role, string> = { en: 'Narrator (English)', A: 'You (Japanese)', B: 'Partner (Japanese)' };

function VoicePicker({ jaVoices, enVoices, chosen, onVoice }: Props) {
  const [open, setOpen] = useState<Role | null>(null);
  return (
    <View>
      {(['en', 'A', 'B'] as Role[]).map((role) => {
        const list = role === 'en' ? enVoices : jaVoices;
        const cur = chosen[role];
        return (
          <View key={role}>
            <Pressable onPress={() => setOpen(open === role ? null : role)} style={s.voiceRow}>
              <View style={{ flex: 1 }}>
                <Text style={s.voiceRole}>{ROLE_LABEL[role]}</Text>
                <Text style={s.voiceName} numberOfLines={1}>{cur ? `${cur.name}` : 'None found'}</Text>
              </View>
              <Text style={s.change}>{open === role ? 'Close' : 'Change'}</Text>
            </Pressable>
            {open === role ? (
              <View style={s.voiceList}>
                <Text style={s.voiceHint}>Tap a voice to hear it. It's saved right away.</Text>
                {list.map((v) => (
                  <Pressable
                    key={v.id}
                    onPress={() => {
                      unlock();
                      preview(v, SAMPLE[role]);
                      onVoice(role, v.id);
                    }}
                    style={[s.voiceOpt, cur?.id === v.id && s.voiceOptOn]}
                  >
                    <Text style={[s.voiceOptName, cur?.id === v.id && { color: C.text }]} numberOfLines={1}>{v.name}</Text>
                    <Text style={s.voiceOptLang}>{v.lang}</Text>
                  </Pressable>
                ))}
                {!list.length ? <Text style={s.voiceHint}>No voices found for this language.</Text> : null}
              </View>
            ) : null}
          </View>
        );
      })}
    </View>
  );
}

export function ProgressScreen(props: Props) {
  const { data, updateSettings, reset } = useStore();
  const [confirm, setConfirm] = useState(false);
  const { current, longest } = streaks(data);
  const totalMin = Math.round(Object.values(data.days).reduce((a, b) => a + b, 0) / 60);
  const today = Math.round((data.days[dayKey()] ?? 0) / 60);
  const done = LESSONS.filter((l) => data.completed[l.id]);
  const words = done.reduce((a, l) => a + l.items.length, 0);
  const { settings } = data;


  return (
    <ScrollView style={{ flex: 1 }} contentContainerStyle={s.wrap}>
      <Text style={s.h1}>Progress</Text>

      <View style={s.streakCard}>
        <Flame size={34} color={current ? C.gold : C.faint} />
        <View style={{ flex: 1 }}>
          <Text style={s.big}>{current} {current === 1 ? 'day' : 'days'}</Text>
          <Text style={s.mutedText}>Current streak · best {longest}</Text>
        </View>
        <View style={{ alignItems: 'flex-end' }}>
          <Text style={s.today}>{today}<Text style={s.todayOf}>/30</Text></Text>
          <Text style={s.mutedText}>min today</Text>
        </View>
      </View>

      <View style={s.card}>
        <Heatmap />
      </View>

      <View style={s.stats}>
        <Stat n={`${done.length}/${LESSONS.length}`} label="lessons" />
        <Stat n={`${words}`} label="words & phrases" />
        <Stat n={totalMin >= 60 ? `${(totalMin / 60).toFixed(1)}h` : `${totalMin}m`} label="listening" />
      </View>

      <Text style={s.section}>Settings</Text>
      <View style={s.card}>
        <Text style={s.label}>Japanese speed</Text>
        <Seg value={settings.rate} onChange={(rate) => updateSettings({ rate })} options={[{ label: 'Slow', value: 0.7 }, { label: 'Normal', value: 0.85 }, { label: 'Natural', value: 1 }]} />
        <Text style={[s.label, { marginTop: 18 }]}>Pauses to speak</Text>
        <Seg value={settings.pauseScale} onChange={(pauseScale) => updateSettings({ pauseScale })} options={[{ label: 'Normal', value: 1 }, { label: 'Longer', value: 1.5 }, { label: 'Longest', value: 2 }]} />
        <Text style={[s.label, { marginTop: 18 }]}>Show Japanese text while listening</Text>
        <Seg value={settings.showText ? 1 : 0} onChange={(v) => updateSettings({ showText: v === 1 })} options={[{ label: 'On', value: 1 }, { label: 'Off (audio only)', value: 0 }]} />
        <Text style={[s.label, { marginTop: 18 }]}>Voices</Text>
        <VoicePicker {...props} />
      </View>

      <Pressable
        onPress={() => {
          if (confirm) {
            reset();
            setConfirm(false);
          } else setConfirm(true);
        }}
        style={s.reset}
      >
        <Text style={{ color: confirm ? C.accent : C.faint, fontSize: 13 }}>{confirm ? 'Tap again to erase all progress' : 'Reset progress'}</Text>
      </Pressable>
    </ScrollView>
  );
}

function Stat({ n, label }: { n: string; label: string }) {
  return (
    <View style={s.stat}>
      <Text style={s.statN}>{n}</Text>
      <Text style={s.mutedText}>{label}</Text>
    </View>
  );
}

const s = StyleSheet.create({
  wrap: { padding: 20, paddingTop: 16, paddingBottom: 40, maxWidth: 560, width: '100%', alignSelf: 'center' },
  h1: { color: C.text, fontSize: 30, fontWeight: '700', letterSpacing: -0.5, marginBottom: 18 },
  streakCard: { backgroundColor: C.surface, borderRadius: 20, padding: 18, flexDirection: 'row', alignItems: 'center', gap: 14, marginBottom: 12 },
  big: { color: C.text, fontSize: 24, fontWeight: '700' },
  today: { color: C.text, fontSize: 24, fontWeight: '700' },
  todayOf: { color: C.faint, fontSize: 15, fontWeight: '500' },
  mutedText: { color: C.muted, fontSize: 12, marginTop: 2 },
  card: { backgroundColor: C.surface, borderRadius: 20, padding: 18, marginBottom: 12 },
  heat: { flexDirection: 'row', justifyContent: 'space-between' },
  col: { gap: 4 },
  cell: { width: 15, height: 15, borderRadius: 4 },
  cellToday: { borderWidth: 1.5, borderColor: C.text },
  cellSm: { width: 10, height: 10, borderRadius: 3 },
  legend: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 12 },
  legendText: { color: C.faint, fontSize: 11 },
  stats: { flexDirection: 'row', gap: 10, marginBottom: 26 },
  stat: { flex: 1, backgroundColor: C.surface, borderRadius: 16, padding: 14 },
  statN: { color: C.text, fontSize: 20, fontWeight: '700' },
  section: { color: C.muted, fontSize: 12, fontWeight: '600', textTransform: 'uppercase', letterSpacing: 1.4, marginBottom: 8 },
  label: { color: C.muted, fontSize: 13, marginBottom: 8 },
  seg: { flexDirection: 'row', backgroundColor: C.bg, borderRadius: 12, padding: 3 },
  segItem: { flex: 1, paddingVertical: 9, borderRadius: 10, alignItems: 'center' },
  segOn: { backgroundColor: C.surface2 },
  segText: { color: C.faint, fontSize: 13, fontWeight: '500' },
  voiceRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 10, gap: 10 },
  voiceRole: { color: C.faint, fontSize: 12 },
  voiceName: { color: C.text, fontSize: 15, marginTop: 2 },
  voiceList: { backgroundColor: C.bg, borderRadius: 12, padding: 6, marginBottom: 8 },
  voiceHint: { color: C.faint, fontSize: 12, padding: 8 },
  voiceOpt: { flexDirection: 'row', alignItems: 'center', paddingVertical: 11, paddingHorizontal: 10, borderRadius: 10 },
  voiceOptOn: { backgroundColor: C.surface2 },
  voiceOptName: { color: C.muted, fontSize: 14, flex: 1 },
  voiceOptLang: { color: C.faint, fontSize: 12, marginLeft: 8 },
  change: { color: C.accent, fontSize: 13, fontWeight: '600' },
  reset: { alignItems: 'center', padding: 16 },
});

export const C = {
  bg: '#0E0F13',
  surface: '#17191F',
  surface2: '#1F222A',
  line: '#2A2E37',
  text: '#F4EFE7',
  muted: '#8D919B',
  faint: '#5A5E68',
  accent: '#E4572E', // vermilion
  accentSoft: 'rgba(228,87,46,0.16)',
  gold: '#E9B44C',
  green: '#7FB685',
};

export const F = {
  jp: { fontSize: 32, fontWeight: '600' as const, color: C.text, letterSpacing: 1 },
};

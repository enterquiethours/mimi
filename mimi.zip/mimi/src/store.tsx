import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';

export type Settings = {
  rate: number; // Japanese speaking speed
  pauseScale: number; // 1 = normal pauses, 1.5 = longer
  showText: boolean; // show the Japanese on screen while listening
  jaA?: string;
  jaB?: string;
  enVoice?: string;
};

/** Flashcard memory: Leitner box and the day the card is next due. */
export type CardState = { box: number; due: string; seen: number; right: number };

export type Data = {
  completed: Record<string, string>; // lessonId -> date finished
  positions: Record<string, number>; // lessonId -> cue index to resume from
  days: Record<string, number>; // YYYY-MM-DD -> seconds practiced
  settings: Settings;
  cards: Record<string, CardState>;
};

const KEY = 'mimi:v1';
export const DAILY_GOAL_SEC = 30 * 60;
const COUNTS_AS_PRACTICE_SEC = 5 * 60;
/** Days until a card comes back, by box. Box 0 = still learning. */
export const BOX_DAYS = [0, 1, 3, 7, 14, 30];

const initial: Data = {
  completed: {},
  positions: {},
  days: {},
  cards: {},
  settings: { rate: 0.85, pauseScale: 1, showText: true },
};

export function dayKey(d = new Date()) {
  const m = `${d.getMonth() + 1}`.padStart(2, '0');
  const day = `${d.getDate()}`.padStart(2, '0');
  return `${d.getFullYear()}-${m}-${day}`;
}

function addDays(d: Date, n: number) {
  const x = new Date(d);
  x.setDate(x.getDate() + n);
  return x;
}

export function practiced(data: Data, key: string) {
  return (data.days[key] ?? 0) >= COUNTS_AS_PRACTICE_SEC || Object.values(data.completed).includes(key);
}

export function streaks(data: Data) {
  const today = new Date();
  const start = practiced(data, dayKey(today)) ? today : addDays(today, -1);
  let current = 0;
  while (practiced(data, dayKey(addDays(start, -current)))) current++;

  const keys = Object.keys(data.days).concat(Object.values(data.completed)).sort();
  let longest = 0;
  if (keys.length) {
    let run = 0;
    for (let d = new Date(keys[0] + 'T12:00:00'); d <= today; d = addDays(d, 1)) {
      run = practiced(data, dayKey(d)) ? run + 1 : 0;
      longest = Math.max(longest, run);
    }
  }
  return { current, longest };
}

type Ctx = {
  data: Data;
  ready: boolean;
  addSeconds: (s: number) => void;
  complete: (lessonId: string) => void;
  savePosition: (lessonId: string, index: number) => void;
  updateSettings: (patch: Partial<Settings>) => void;
  gradeCard: (key: string, knewIt: boolean) => void;
  reset: () => void;
};

const StoreCtx = createContext<Ctx | null>(null);

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [data, setData] = useState<Data>(initial);
  const [ready, setReady] = useState(false);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    AsyncStorage.getItem(KEY)
      .then((raw) => {
        if (raw) {
          const parsed = JSON.parse(raw) as Partial<Data>;
          setData({ ...initial, ...parsed, cards: parsed.cards ?? {}, settings: { ...initial.settings, ...parsed.settings } });
        }
      })
      .catch(() => {})
      .finally(() => setReady(true));
  }, []);

  const mutate = useCallback((fn: (d: Data) => Data) => {
    setData((prev) => {
      const next = fn(prev);
      if (saveTimer.current) clearTimeout(saveTimer.current);
      saveTimer.current = setTimeout(() => {
        AsyncStorage.setItem(KEY, JSON.stringify(next)).catch(() => {});
      }, 400);
      return next;
    });
  }, []);

  const value = useMemo<Ctx>(
    () => ({
      data,
      ready,
      addSeconds: (s) => mutate((d) => ({ ...d, days: { ...d.days, [dayKey()]: (d.days[dayKey()] ?? 0) + s } })),
      complete: (id) =>
        mutate((d) => ({
          ...d,
          completed: { ...d.completed, [id]: d.completed[id] ?? dayKey() },
          positions: { ...d.positions, [id]: 0 },
        })),
      savePosition: (id, index) => mutate((d) => ({ ...d, positions: { ...d.positions, [id]: index } })),
      gradeCard: (key, knewIt) =>
        mutate((d) => {
          const prev = d.cards[key] ?? { box: 0, due: dayKey(), seen: 0, right: 0 };
          const box = knewIt ? Math.min(prev.box + 1, BOX_DAYS.length - 1) : 0;
          const due = dayKey(addDays(new Date(), BOX_DAYS[box]));
          return { ...d, cards: { ...d.cards, [key]: { box, due, seen: prev.seen + 1, right: prev.right + (knewIt ? 1 : 0) } } };
        }),
      updateSettings: (patch) => mutate((d) => ({ ...d, settings: { ...d.settings, ...patch } })),
      reset: () => mutate(() => initial),
    }),
    [data, ready, mutate],
  );

  return <StoreCtx.Provider value={value}>{children}</StoreCtx.Provider>;
}

export function useStore() {
  const c = useContext(StoreCtx);
  if (!c) throw new Error('useStore outside provider');
  return c;
}

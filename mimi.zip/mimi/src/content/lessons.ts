// Lesson content. Kana is written with spaces between word groups so the
// engine can build phrases back up from the end, one group at a time.
// `ro` is the romaji shown on screen; `en` is what the narrator says.

export type Speaker = 'A' | 'B';

export type Line = {
  kana: string;
  ro: string;
  en: string;
  who?: Speaker;
};

export type Item = Line & {
  id: string;
  kind: 'word' | 'phrase';
  /** Optional narrator line used instead of the default introduction. */
  intro?: string;
  /** Optional pronunciation or usage tip, spoken after the breakdown. */
  tip?: string;
};

export type RolePlay = {
  /** What the other person says first (optional). */
  ask?: Line;
  /** English instruction from the narrator. */
  cue: string;
  /** The answer you should give. */
  answer: Line;
};

export type Lesson = {
  id: string;
  n: number;
  title: string;
  jp: string;
  scene: string;
  dialogue: Line[];
  items: Item[];
  roleplay: RolePlay[];
};

const A = (kana: string, ro: string, en: string): Line => ({ kana, ro, en, who: 'A' });
const B = (kana: string, ro: string, en: string): Line => ({ kana, ro, en, who: 'B' });
const w = (id: string, kana: string, ro: string, en: string, extra: Partial<Item> = {}): Item => ({
  id, kind: 'word', kana, ro, en, ...extra,
});
const p = (id: string, kana: string, ro: string, en: string, extra: Partial<Item> = {}): Item => ({
  id, kind: 'phrase', kana, ro, en, ...extra,
});
const ans = (kana: string, ro: string, en: string): Line => ({ kana, ro, en, who: 'A' });

export const LESSONS: Lesson[] = [
  {
    id: 'l1', n: 1, title: 'First words', jp: 'はじめの ことば',
    scene: 'You have just arrived in Tokyo. An American woman stops a man on the street. Listen to their conversation. You will not understand it yet, but by the end of this lesson, you will.',
    dialogue: [
      A('すみません。', 'Sumimasen.', 'Excuse me.'),
      B('はい。', 'Hai.', 'Yes?'),
      A('えいごが わかりますか。', 'Eigo ga wakarimasu ka?', 'Do you understand English?'),
      B('いいえ、 わかりません。', 'Iie, wakarimasen.', 'No, I don’t.'),
      A('そうですか。 にほんごは すこし わかります。', 'Sō desu ka. Nihongo wa sukoshi wakarimasu.', 'I see. I understand a little Japanese.'),
      B('ああ、 そうですか。', 'Ā, sō desu ka.', 'Oh, I see.'),
      A('でも、 あまり はなせません。', 'Demo, amari hanasemasen.', 'But I can’t speak very much.'),
    ],
    items: [
      w('sumimasen', 'すみません', 'sumimasen', 'excuse me', { tip: 'The "u" in "su" is very light. It sounds almost like "smee-mah-sen."' }),
      w('hai', 'はい', 'hai', 'yes'),
      w('iie', 'いいえ', 'iie', 'no', { tip: 'Hold the first sound a little longer: "ee-eh."' }),
      w('eigo', 'えいご', 'eigo', 'English, the language'),
      w('wakarimasu', 'わかります', 'wakarimasu', 'I understand'),
      p('eigo-ga-wakarimasu-ka', 'えいごが わかりますか', 'eigo ga wakarimasu ka', 'Do you understand English?', { intro: 'To ask a question, add "ka" to the end. Here is how to ask, "Do you understand English?"' }),
      w('wakarimasen', 'わかりません', 'wakarimasen', 'I don’t understand', { intro: 'Change "masu" to "masen" to make it negative. "I don’t understand."' }),
      p('iie-wakarimasen', 'いいえ、 わかりません', 'iie, wakarimasen', 'No, I don’t understand.'),
      w('nihongo', 'にほんご', 'nihongo', 'Japanese, the language'),
      w('sukoshi', 'すこし', 'sukoshi', 'a little'),
      p('nihongo-sukoshi', 'にほんごは すこし わかります', 'nihongo wa sukoshi wakarimasu', 'I understand a little Japanese.'),
      w('sou-desu-ka', 'そうですか', 'sō desu ka', 'I see', { tip: 'Said with a falling tone, this means "I see." You will use it all the time.' }),
      w('demo', 'でも', 'demo', 'but'),
      w('amari', 'あまり', 'amari', 'not very much', { tip: '"Amari" goes with a negative verb.' }),
      w('hanasemasen', 'はなせません', 'hanasemasen', 'I can’t speak'),
      p('amari-hanasemasen', 'にほんごは あまり はなせません', 'nihongo wa amari hanasemasen', 'I can’t speak Japanese very well.'),
    ],
    roleplay: [
      { cue: 'You need help. Politely get someone’s attention.', answer: ans('すみません。', 'Sumimasen.', 'Excuse me.') },
      { ask: B('はい。', 'Hai.', 'Yes?'), cue: 'Ask him if he understands English.', answer: ans('えいごが わかりますか。', 'Eigo ga wakarimasu ka?', 'Do you understand English?') },
      { ask: B('いいえ、 わかりません。', 'Iie, wakarimasen.', 'No, I don’t.'), cue: 'Say "I see," and tell him you understand a little Japanese.', answer: ans('そうですか。 にほんごは すこし わかります。', 'Sō desu ka. Nihongo wa sukoshi wakarimasu.', 'I see. I understand a little Japanese.') },
      { cue: 'Now tell him, "But I can’t speak very much."', answer: ans('でも、 あまり はなせません。', 'Demo, amari hanasemasen.', 'But I can’t speak very much.') },
      { ask: B('えいごが わかりますか。', 'Eigo ga wakarimasu ka?', 'Do you understand English?'), cue: 'Someone asks if you understand English. Say yes, you understand.', answer: ans('はい、 わかります。', 'Hai, wakarimasu.', 'Yes, I understand.') },
      { ask: B('にほんごが わかりますか。', 'Nihongo ga wakarimasu ka?', 'Do you understand Japanese?'), cue: 'Tell her you understand a little.', answer: ans('すこし わかります。', 'Sukoshi wakarimasu.', 'I understand a little.') },
    ],
  },

  {
    id: 'l2', n: 2, title: 'Nice to meet you', jp: 'はじめまして',
    scene: 'At a dance studio in Tokyo, you meet another dancer named Yuki. Listen.',
    dialogue: [
      B('こんにちは。', 'Konnichiwa.', 'Hello.'),
      A('こんにちは。 はじめまして。 クリスティーナです。', 'Konnichiwa. Hajimemashite. Kurisutīna desu.', 'Hello. Nice to meet you. I’m Christina.'),
      B('はじめまして。 ゆきです。', 'Hajimemashite. Yuki desu.', 'Nice to meet you. I’m Yuki.'),
      B('アメリカじんですか。', 'Amerikajin desu ka?', 'Are you American?'),
      A('はい、 アメリカじんです。 ニューヨークから きました。', 'Hai, Amerikajin desu. Nyū Yōku kara kimashita.', 'Yes, I’m American. I came from New York.'),
      B('そうですか。 よろしく おねがいします。', 'Sō desu ka. Yoroshiku onegaishimasu.', 'I see. Nice to meet you.'),
      A('こちらこそ、 よろしく おねがいします。', 'Kochira koso, yoroshiku onegaishimasu.', 'Likewise, nice to meet you.'),
    ],
    items: [
      w('konnichiwa', 'こんにちは', 'konnichiwa', 'hello'),
      w('hajimemashite', 'はじめまして', 'hajimemashite', 'nice to meet you, the first time you meet', { tip: 'The "i" in "shi" nearly disappears: "hah-jee-meh-mash-teh."' }),
      w('watashi', 'わたし', 'watashi', 'I, or me'),
      p('watashi-wa-christina', 'わたしは クリスティーナです', 'watashi wa Kurisutīna desu', 'I’m Christina.', { tip: '"Desu" sounds like "dess." The final "u" is almost silent.' }),
      p('onamae-wa', 'おなまえは？', 'onamae wa?', 'What’s your name?'),
      w('amerikajin', 'アメリカじん', 'Amerikajin', 'an American', { intro: 'Add "jin" to a country to say a person from there. "An American."' }),
      p('amerikajin-desu-ka', 'アメリカじんですか', 'Amerikajin desu ka', 'Are you American?'),
      p('hai-amerikajin', 'はい、 アメリカじんです', 'hai, Amerikajin desu', 'Yes, I’m American.'),
      w('kara', 'から', 'kara', 'from'),
      w('kimashita', 'きました', 'kimashita', 'came'),
      p('ny-kara-kimashita', 'ニューヨークから きました', 'Nyū Yōku kara kimashita', 'I came from New York.'),
      p('yoroshiku', 'よろしく おねがいします', 'yoroshiku onegaishimasu', 'nice to meet you, or I look forward to knowing you'),
      w('kochira-koso', 'こちらこそ', 'kochira koso', 'likewise, the pleasure is mine'),
    ],
    roleplay: [
      { ask: B('こんにちは。', 'Konnichiwa.', 'Hello.'), cue: 'Say hello back, and "nice to meet you."', answer: ans('こんにちは。 はじめまして。', 'Konnichiwa. Hajimemashite.', 'Hello. Nice to meet you.') },
      { ask: B('おなまえは？', 'Onamae wa?', 'Your name?'), cue: 'She is asking your name. Tell her.', answer: ans('クリスティーナです。', 'Kurisutīna desu.', 'I’m Christina.') },
      { ask: B('アメリカじんですか。', 'Amerikajin desu ka?', 'Are you American?'), cue: 'Yes, you are.', answer: ans('はい、 アメリカじんです。', 'Hai, Amerikajin desu.', 'Yes, I’m American.') },
      { cue: 'Tell her you came from New York.', answer: ans('ニューヨークから きました。', 'Nyū Yōku kara kimashita.', 'I came from New York.') },
      { ask: B('よろしく おねがいします。', 'Yoroshiku onegaishimasu.', 'Nice to meet you.'), cue: 'Answer: "Likewise, nice to meet you."', answer: ans('こちらこそ、 よろしく おねがいします。', 'Kochira koso, yoroshiku onegaishimasu.', 'Likewise, nice to meet you.') },
      { ask: B('にほんごが わかりますか。', 'Nihongo ga wakarimasu ka?', 'Do you understand Japanese?'), cue: 'Tell her you understand a little, but can’t speak very much.', answer: ans('すこし わかります。 でも、 あまり はなせません。', 'Sukoshi wakarimasu. Demo, amari hanasemasen.', 'I understand a little. But I can’t speak much.') },
    ],
  },

  {
    id: 'l3', n: 3, title: 'Where is it?', jp: 'どこですか',
    scene: 'You are looking for the train station. You stop a man and ask for directions.',
    dialogue: [
      A('すみません。 えきは どこですか。', 'Sumimasen. Eki wa doko desu ka?', 'Excuse me. Where is the station?'),
      B('えきですか。 まっすぐ いって、 みぎです。', 'Eki desu ka. Massugu itte, migi desu.', 'The station? Go straight, and it’s on the right.'),
      A('すみません、 もういちど おねがいします。', 'Sumimasen, mō ichido onegaishimasu.', 'Sorry, one more time please.'),
      B('まっすぐ いって、 みぎです。', 'Massugu itte, migi desu.', 'Go straight, and it’s on the right.'),
      A('わかりました。 ありがとうございます。', 'Wakarimashita. Arigatō gozaimasu.', 'Got it. Thank you.'),
      B('どういたしまして。', 'Dō itashimashite.', 'You’re welcome.'),
    ],
    items: [
      w('doko', 'どこ', 'doko', 'where'),
      w('eki', 'えき', 'eki', 'the station'),
      p('eki-doko', 'えきは どこですか', 'eki wa doko desu ka', 'Where is the station?'),
      w('toire', 'トイレ', 'toire', 'the restroom'),
      p('toire-doko', 'トイレは どこですか', 'toire wa doko desu ka', 'Where is the restroom?'),
      w('massugu', 'まっすぐ', 'massugu', 'straight ahead', { tip: 'The small pause before "su" is part of the word: "mas-sugu."' }),
      w('migi', 'みぎ', 'migi', 'right'),
      w('hidari', 'ひだり', 'hidari', 'left'),
      p('massugu-migi', 'まっすぐ いって、 みぎです', 'massugu itte, migi desu', 'Go straight, and it’s on the right.'),
      w('onegaishimasu', 'おねがいします', 'onegaishimasu', 'please, when asking for something'),
      w('mou-ichido', 'もういちど', 'mō ichido', 'one more time'),
      p('mou-ichido-onegai', 'もういちど おねがいします', 'mō ichido onegaishimasu', 'One more time, please.'),
      w('yukkuri', 'ゆっくり', 'yukkuri', 'slowly'),
      p('yukkuri-onegai', 'ゆっくり おねがいします', 'yukkuri onegaishimasu', 'Slowly, please.'),
      w('wakarimashita', 'わかりました', 'wakarimashita', 'got it, I understood'),
      w('arigatou', 'ありがとうございます', 'arigatō gozaimasu', 'thank you'),
      w('dou-itashimashite', 'どういたしまして', 'dō itashimashite', 'you’re welcome'),
    ],
    roleplay: [
      { cue: 'Stop someone and ask where the station is.', answer: ans('すみません、 えきは どこですか。', 'Sumimasen, eki wa doko desu ka?', 'Excuse me, where is the station?') },
      { ask: B('まっすぐ いって、 ひだりです。', 'Massugu itte, hidari desu.', 'Go straight, and it’s on the left.'), cue: 'That was fast. Ask him to say it one more time.', answer: ans('もういちど おねがいします。', 'Mō ichido onegaishimasu.', 'One more time, please.') },
      { ask: B('まっすぐ いって、 ひだりです。', 'Massugu itte, hidari desu.', 'Go straight, and it’s on the left.'), cue: 'Tell him you got it, and thank him.', answer: ans('わかりました。 ありがとうございます。', 'Wakarimashita. Arigatō gozaimasu.', 'Got it. Thank you.') },
      { cue: 'Now ask a woman where the restroom is.', answer: ans('すみません、 トイレは どこですか。', 'Sumimasen, toire wa doko desu ka?', 'Excuse me, where is the restroom?') },
      { ask: B('トイレは まっすぐ いって、 みぎです。', 'Toire wa massugu itte, migi desu.', 'The restroom is straight ahead, on the right.'), cue: 'She is speaking quickly. Ask her to speak slowly, please.', answer: ans('ゆっくり おねがいします。', 'Yukkuri onegaishimasu.', 'Slowly, please.') },
      { ask: B('ありがとうございます。', 'Arigatō gozaimasu.', 'Thank you.'), cue: 'Someone thanks you for helping. Say "you’re welcome."', answer: ans('どういたしまして。', 'Dō itashimashite.', 'You’re welcome.') },
    ],
  },

  {
    id: 'l4', n: 4, title: 'At the grocery store', jp: 'スーパーで',
    scene: 'You are shopping at a supermarket. First you look for water, then you go to the register.',
    dialogue: [
      A('すみません、 みずは ありますか。', 'Sumimasen, mizu wa arimasu ka?', 'Excuse me, do you have water?'),
      B('はい、 あちらです。', 'Hai, achira desu.', 'Yes, it’s over there.'),
      B('いらっしゃいませ。', 'Irasshaimase.', 'Welcome.'),
      A('これ、 おねがいします。', 'Kore, onegaishimasu.', 'This, please.'),
      B('ふくろは いりますか。', 'Fukuro wa irimasu ka?', 'Do you need a bag?'),
      A('いいえ、 だいじょうぶです。 カードで いいですか。', 'Iie, daijōbu desu. Kādo de ii desu ka?', 'No, I’m fine. Is card OK?'),
      B('はい、 どうぞ。', 'Hai, dōzo.', 'Yes, go ahead.'),
    ],
    items: [
      w('mizu', 'みず', 'mizu', 'water'),
      w('arimasu-ka', 'ありますか', 'arimasu ka', 'do you have it? or, is there?'),
      p('mizu-arimasu-ka', 'みずは ありますか', 'mizu wa arimasu ka', 'Do you have water?'),
      w('achira', 'あちら', 'achira', 'over there'),
      w('irasshaimase', 'いらっしゃいませ', 'irasshaimase', 'welcome, what shop staff say', { tip: 'You will hear this in every shop. You don’t need to answer it.' }),
      w('kore', 'これ', 'kore', 'this'),
      p('kore-onegai', 'これ、 おねがいします', 'kore, onegaishimasu', 'This, please.'),
      w('ikura', 'いくら', 'ikura', 'how much'),
      p('kore-ikura', 'これは いくらですか', 'kore wa ikura desu ka', 'How much is this?'),
      w('fukuro', 'ふくろ', 'fukuro', 'a bag'),
      w('irimasu-ka', 'いりますか', 'irimasu ka', 'do you need it?'),
      p('fukuro-irimasu-ka', 'ふくろは いりますか', 'fukuro wa irimasu ka', 'Do you need a bag?'),
      w('daijoubu', 'だいじょうぶです', 'daijōbu desu', 'I’m fine, or no thank you'),
      p('iie-daijoubu', 'いいえ、 だいじょうぶです', 'iie, daijōbu desu', 'No, I’m fine.'),
      w('kaado', 'カード', 'kādo', 'card'),
      p('kaado-de-ii', 'カードで いいですか', 'kādo de ii desu ka', 'Is card OK?'),
      w('douzo', 'どうぞ', 'dōzo', 'go ahead, or here you are'),
    ],
    roleplay: [
      { cue: 'You can’t find the water. Ask a clerk if they have water.', answer: ans('すみません、 みずは ありますか。', 'Sumimasen, mizu wa arimasu ka?', 'Excuse me, do you have water?') },
      { ask: B('はい、 あちらです。', 'Hai, achira desu.', 'Yes, it’s over there.'), cue: 'Thank her.', answer: ans('ありがとうございます。', 'Arigatō gozaimasu.', 'Thank you.') },
      { cue: 'You pick up some fruit. Ask how much it is.', answer: ans('これは いくらですか。', 'Kore wa ikura desu ka?', 'How much is this?') },
      { ask: B('いらっしゃいませ。', 'Irasshaimase.', 'Welcome.'), cue: 'At the register, hand over your things and say "This, please."', answer: ans('これ、 おねがいします。', 'Kore, onegaishimasu.', 'This, please.') },
      { ask: B('ふくろは いりますか。', 'Fukuro wa irimasu ka?', 'Do you need a bag?'), cue: 'You brought your own bag. Say no, you’re fine.', answer: ans('いいえ、 だいじょうぶです。', 'Iie, daijōbu desu.', 'No, I’m fine.') },
      { cue: 'Ask if you can pay by card.', answer: ans('カードで いいですか。', 'Kādo de ii desu ka?', 'Is card OK?') },
    ],
  },

  {
    id: 'l5', n: 5, title: 'At the café', jp: 'カフェで',
    scene: 'You walk into a small café and order a drink.',
    dialogue: [
      B('いらっしゃいませ。 ごちゅうもんは？', 'Irasshaimase. Gochūmon wa?', 'Welcome. What would you like?'),
      A('コーヒーを ひとつ おねがいします。', 'Kōhī o hitotsu onegaishimasu.', 'One coffee, please.'),
      B('ホットですか、 アイスですか。', 'Hotto desu ka, aisu desu ka?', 'Hot or iced?'),
      A('アイスで おねがいします。', 'Aisu de onegaishimasu.', 'Iced, please.'),
      B('はい、 どうぞ。', 'Hai, dōzo.', 'Here you are.'),
      A('ありがとうございます。 おいしいです！', 'Arigatō gozaimasu. Oishii desu!', 'Thank you. It’s delicious!'),
      A('すみません、 おかいけい おねがいします。', 'Sumimasen, okaikei onegaishimasu.', 'Excuse me, the check please.'),
      A('ごちそうさまでした。', 'Gochisōsama deshita.', 'Thank you for the meal.'),
    ],
    items: [
      p('gochuumon', 'ごちゅうもんは？', 'gochūmon wa?', 'What would you like to order?'),
      w('koohii', 'コーヒー', 'kōhī', 'coffee'),
      w('ocha', 'おちゃ', 'ocha', 'green tea'),
      w('hitotsu', 'ひとつ', 'hitotsu', 'one, when counting things'),
      w('futatsu', 'ふたつ', 'futatsu', 'two, when counting things'),
      p('koohii-hitotsu', 'コーヒーを ひとつ おねがいします', 'kōhī o hitotsu onegaishimasu', 'One coffee, please.'),
      p('ocha-futatsu', 'おちゃを ふたつ おねがいします', 'ocha o futatsu onegaishimasu', 'Two green teas, please.'),
      w('hotto', 'ホット', 'hotto', 'hot, for a drink'),
      w('aisu', 'アイス', 'aisu', 'iced'),
      p('aisu-de-onegai', 'アイスで おねがいします', 'aisu de onegaishimasu', 'Iced, please.'),
      w('oishii', 'おいしい', 'oishii', 'delicious'),
      p('oishii-desu', 'おいしいです', 'oishii desu', 'It’s delicious!'),
      w('okaikei', 'おかいけい', 'okaikei', 'the check, or bill'),
      p('okaikei-onegai', 'おかいけい おねがいします', 'okaikei onegaishimasu', 'The check, please.'),
      w('gochisousama', 'ごちそうさまでした', 'gochisōsama deshita', 'thank you for the meal, said after eating'),
    ],
    roleplay: [
      { ask: B('ごちゅうもんは？', 'Gochūmon wa?', 'What would you like?'), cue: 'Order one coffee.', answer: ans('コーヒーを ひとつ おねがいします。', 'Kōhī o hitotsu onegaishimasu.', 'One coffee, please.') },
      { ask: B('ホットですか、 アイスですか。', 'Hotto desu ka, aisu desu ka?', 'Hot or iced?'), cue: 'It’s summer. Ask for iced.', answer: ans('アイスで おねがいします。', 'Aisu de onegaishimasu.', 'Iced, please.') },
      { cue: 'Your friend arrives. Order two green teas.', answer: ans('おちゃを ふたつ おねがいします。', 'Ocha o futatsu onegaishimasu.', 'Two green teas, please.') },
      { cue: 'Take a sip. Tell the server it’s delicious.', answer: ans('おいしいです！', 'Oishii desu!', 'It’s delicious!') },
      { cue: 'Get the server’s attention and ask for the check.', answer: ans('すみません、 おかいけい おねがいします。', 'Sumimasen, okaikei onegaishimasu.', 'Excuse me, the check please.') },
      { cue: 'On your way out, thank them for the meal.', answer: ans('ごちそうさまでした。', 'Gochisōsama deshita.', 'Thank you for the meal.') },
    ],
  },

  {
    id: 'l6', n: 6, title: 'I love to dance', jp: 'ダンスが だいすき',
    scene: 'After class, Yuki asks about your hobbies.',
    dialogue: [
      B('クリスティーナさんの しゅみは なんですか。', 'Kurisutīna-san no shumi wa nan desu ka?', 'Christina, what’s your hobby?'),
      A('ダンスです。 ダンスが だいすきです。', 'Dansu desu. Dansu ga daisuki desu.', 'Dance. I love dance.'),
      B('へえ、 いつから おどっていますか。', 'Hē, itsu kara odotte imasu ka?', 'Oh, since when have you been dancing?'),
      A('ごさいから おどっています。', 'Gosai kara odotte imasu.', 'I’ve been dancing since I was five.'),
      B('すごいですね！ どんな ダンスですか。', 'Sugoi desu ne! Donna dansu desu ka?', 'That’s amazing! What kind of dance?'),
      A('ジャズと バレエと ヒップホップです。', 'Jazu to barē to hippuhoppu desu.', 'Jazz, ballet, and hip-hop.'),
      B('いいですね。', 'Ii desu ne.', 'That’s great.'),
    ],
    items: [
      w('shumi', 'しゅみ', 'shumi', 'hobby'),
      w('nan-desu-ka', 'なんですか', 'nan desu ka', 'what is it?'),
      p('shumi-nan', 'しゅみは なんですか', 'shumi wa nan desu ka', 'What’s your hobby?'),
      w('dansu', 'ダンス', 'dansu', 'dance'),
      w('daisuki', 'だいすき', 'daisuki', 'to really love'),
      p('dansu-daisuki', 'ダンスが だいすきです', 'dansu ga daisuki desu', 'I love dance.'),
      w('itsu-kara', 'いつから', 'itsu kara', 'since when'),
      w('odotte-imasu', 'おどっています', 'odotte imasu', 'I’ve been dancing'),
      p('itsu-kara-odotte', 'いつから おどっていますか', 'itsu kara odotte imasu ka', 'Since when have you been dancing?'),
      w('gosai', 'ごさい', 'gosai', 'five years old'),
      p('gosai-kara', 'ごさいから おどっています', 'gosai kara odotte imasu', 'I’ve been dancing since I was five.'),
      w('sugoi', 'すごい', 'sugoi', 'amazing'),
      p('sugoi-desu-ne', 'すごいですね', 'sugoi desu ne', 'That’s amazing!', { tip: '"Ne" at the end is like saying "isn’t it?" It invites the other person to agree.' }),
      w('donna', 'どんな', 'donna', 'what kind of'),
      p('donna-dansu', 'どんな ダンスですか', 'donna dansu desu ka', 'What kind of dance?'),
      w('jazu', 'ジャズ', 'jazu', 'jazz'),
      w('baree', 'バレエ', 'barē', 'ballet'),
      p('jazu-to-baree', 'ジャズと バレエです', 'jazu to barē desu', 'Jazz and ballet.', { intro: '"To" means "and" between two things. Here is "Jazz and ballet."' }),
      w('ii-desu-ne', 'いいですね', 'ii desu ne', 'that’s nice, or sounds good'),
    ],
    roleplay: [
      { ask: B('しゅみは なんですか。', 'Shumi wa nan desu ka?', 'What’s your hobby?'), cue: 'Tell her your hobby is dance.', answer: ans('ダンスです。', 'Dansu desu.', 'Dance.') },
      { cue: 'Tell her you really love dance.', answer: ans('ダンスが だいすきです。', 'Dansu ga daisuki desu.', 'I love dance.') },
      { ask: B('いつから おどっていますか。', 'Itsu kara odotte imasu ka?', 'Since when have you been dancing?'), cue: 'Since you were five.', answer: ans('ごさいから おどっています。', 'Gosai kara odotte imasu.', 'Since I was five.') },
      { ask: B('どんな ダンスですか。', 'Donna dansu desu ka?', 'What kind of dance?'), cue: 'Jazz and ballet.', answer: ans('ジャズと バレエです。', 'Jazu to barē desu.', 'Jazz and ballet.') },
      { cue: 'Now ask her what her hobby is.', answer: ans('しゅみは なんですか。', 'Shumi wa nan desu ka?', 'What’s your hobby?') },
      { ask: B('ヨガです。', 'Yoga desu.', 'Yoga.'), cue: 'Tell her that’s nice.', answer: ans('いいですね。', 'Ii desu ne.', 'That’s nice.') },
    ],
  },

  {
    id: 'l7', n: 7, title: 'What I do', jp: 'わたしの しごと',
    scene: 'A new friend asks what you do for work.',
    dialogue: [
      B('おしごとは なんですか。', 'Oshigoto wa nan desu ka?', 'What do you do for work?'),
      A('いまは ストレッチの せんせいです。', 'Ima wa sutoretchi no sensei desu.', 'Right now I’m a stretching teacher.'),
      B('へえ、 どこで おしえていますか。', 'Hē, doko de oshiete imasu ka?', 'Oh, where do you teach?'),
      A('ニュージャージーの ワイエムシーエーで おしえています。', 'Nyū Jājī no Wai-emu-shī-ē de oshiete imasu.', 'I teach at the YMCA in New Jersey.'),
      A('まえは こくれんで はたらいていました。', 'Mae wa Kokuren de hataraite imashita.', 'Before, I worked at the UN.'),
      B('こくれん！ すごいですね。 いそがしいですね。', 'Kokuren! Sugoi desu ne. Isogashii desu ne.', 'The UN! Amazing. You must be busy.'),
      A('はい、 でも たのしいです。', 'Hai, demo tanoshii desu.', 'Yes, but it’s fun.'),
    ],
    items: [
      w('oshigoto', 'おしごと', 'oshigoto', 'your work, or job', { tip: 'The "o" in front makes it polite. Use it when asking about someone else’s job.' }),
      p('oshigoto-nan', 'おしごとは なんですか', 'oshigoto wa nan desu ka', 'What do you do for work?'),
      w('ima', 'いま', 'ima', 'now'),
      w('sensei', 'せんせい', 'sensei', 'teacher'),
      w('sutoretchi', 'ストレッチ', 'sutoretchi', 'stretching'),
      p('stretch-sensei', 'いまは ストレッチの せんせいです', 'ima wa sutoretchi no sensei desu', 'Right now I’m a stretching teacher.', { tip: '"No" connects two nouns, like "stretching’s teacher."' }),
      w('doko-de', 'どこで', 'doko de', 'where, when asking where someone does something'),
      w('oshiete-imasu', 'おしえています', 'oshiete imasu', 'I teach, or I’m teaching'),
      p('doko-de-oshiete', 'どこで おしえていますか', 'doko de oshiete imasu ka', 'Where do you teach?'),
      p('ymca', 'ニュージャージーの ワイエムシーエーで おしえています', 'Nyū Jājī no Wai-emu-shī-ē de oshiete imasu', 'I teach at the YMCA in New Jersey.'),
      w('mae-wa', 'まえは', 'mae wa', 'before, or previously'),
      w('kokuren', 'こくれん', 'Kokuren', 'the United Nations'),
      w('hataraite-imashita', 'はたらいていました', 'hataraite imashita', 'I was working'),
      p('kokuren-de', 'まえは こくれんで はたらいていました', 'mae wa Kokuren de hataraite imashita', 'Before, I worked at the UN.'),
      w('isogashii', 'いそがしい', 'isogashii', 'busy'),
      w('tanoshii', 'たのしい', 'tanoshii', 'fun'),
      p('demo-tanoshii', 'でも、 たのしいです', 'demo, tanoshii desu', 'But it’s fun.'),
    ],
    roleplay: [
      { ask: B('おしごとは なんですか。', 'Oshigoto wa nan desu ka?', 'What do you do for work?'), cue: 'Tell him that right now you’re a stretching teacher.', answer: ans('いまは ストレッチの せんせいです。', 'Ima wa sutoretchi no sensei desu.', 'Right now I’m a stretching teacher.') },
      { ask: B('どこで おしえていますか。', 'Doko de oshiete imasu ka?', 'Where do you teach?'), cue: 'At the YMCA in New Jersey.', answer: ans('ニュージャージーの ワイエムシーエーで おしえています。', 'Nyū Jājī no Wai-emu-shī-ē de oshiete imasu.', 'I teach at the YMCA in New Jersey.') },
      { cue: 'Tell him that before, you worked at the UN.', answer: ans('まえは こくれんで はたらいていました。', 'Mae wa Kokuren de hataraite imashita.', 'Before, I worked at the UN.') },
      { ask: B('いそがしいですね。', 'Isogashii desu ne.', 'You must be busy.'), cue: 'Say yes, but it’s fun.', answer: ans('はい、 でも たのしいです。', 'Hai, demo tanoshii desu.', 'Yes, but it’s fun.') },
      { cue: 'Now ask him what he does for work.', answer: ans('おしごとは なんですか。', 'Oshigoto wa nan desu ka?', 'What do you do for work?') },
      { ask: B('わたしも せんせいです。', 'Watashi mo sensei desu.', 'I’m a teacher too.'), cue: 'He’s a teacher too. Say "I see!"', answer: ans('そうですか！', 'Sō desu ka!', 'I see!') },
    ],
  },

  {
    id: 'l8', n: 8, title: 'Teaching a stretch class', jp: 'ストレッチの クラス',
    scene: 'You are leading a stretch class in Japanese. Listen to the teacher guide her students.',
    dialogue: [
      A('みなさん、 こんにちは。', 'Minasan, konnichiwa.', 'Hello, everyone.'),
      B('こんにちは！', 'Konnichiwa!', 'Hello!'),
      A('じゃあ、 はじめましょう。 いきを すって…… はいて……', 'Jā, hajimemashō. Iki o sutte... haite...', 'OK, let’s begin. Breathe in... breathe out...'),
      A('てを あげて ください。 ゆっくり。', 'Te o agete kudasai. Yukkuri.', 'Raise your arms, please. Slowly.'),
      A('いいですね。 むりしないで くださいね。', 'Ii desu ne. Muri shinaide kudasai ne.', 'Good. Don’t push yourself, OK?'),
      A('てを おろして ください。 リラックスして ください。', 'Te o oroshite kudasai. Rirakkusu shite kudasai.', 'Lower your arms. Relax.'),
      A('おつかれさまでした！', 'Otsukaresama deshita!', 'Great work, everyone!'),
    ],
    items: [
      w('minasan', 'みなさん', 'minasan', 'everyone'),
      p('minasan-konnichiwa', 'みなさん、 こんにちは', 'minasan, konnichiwa', 'Hello, everyone.'),
      w('jaa', 'じゃあ', 'jā', 'OK then, or well then'),
      w('hajimemashou', 'はじめましょう', 'hajimemashō', 'let’s begin'),
      p('jaa-hajimemashou', 'じゃあ、 はじめましょう', 'jā, hajimemashō', 'OK, let’s begin.'),
      w('iki', 'いき', 'iki', 'breath'),
      w('sutte', 'すって', 'sutte', 'breathe in'),
      p('iki-wo-sutte', 'いきを すって', 'iki o sutte', 'Breathe in.'),
      w('haite', 'はいて', 'haite', 'breathe out'),
      w('kudasai', 'ください', 'kudasai', 'please, after an action'),
      w('te', 'て', 'te', 'hands, or arms'),
      w('agete', 'あげて', 'agete', 'raise'),
      p('te-agete', 'てを あげて ください', 'te o agete kudasai', 'Raise your arms, please.'),
      w('oroshite', 'おろして', 'oroshite', 'lower'),
      p('te-oroshite', 'てを おろして ください', 'te o oroshite kudasai', 'Lower your arms, please.'),
      p('muri-shinaide', 'むりしないで ください', 'muri shinaide kudasai', 'Please don’t push yourself too hard.'),
      p('rirakkusu', 'リラックスして ください', 'rirakkusu shite kudasai', 'Please relax.'),
      w('otsukaresama', 'おつかれさまでした', 'otsukaresama deshita', 'great work, said at the end of class or work'),
    ],
    roleplay: [
      { cue: 'Class is starting. Greet everyone.', answer: ans('みなさん、 こんにちは。', 'Minasan, konnichiwa.', 'Hello, everyone.') },
      { cue: 'Tell them, "OK, let’s begin."', answer: ans('じゃあ、 はじめましょう。', 'Jā, hajimemashō.', 'OK, let’s begin.') },
      { cue: 'Tell the class to breathe in.', answer: ans('いきを すって。', 'Iki o sutte.', 'Breathe in.') },
      { cue: 'And now, breathe out.', answer: ans('はいて。', 'Haite.', 'Breathe out.') },
      { cue: 'Ask them to raise their arms, slowly.', answer: ans('ゆっくり てを あげて ください。', 'Yukkuri te o agete kudasai.', 'Slowly raise your arms, please.') },
      { cue: 'One student is straining. Tell her not to push too hard.', answer: ans('むりしないで ください。', 'Muri shinaide kudasai.', 'Please don’t push too hard.') },
      { cue: 'Ask them to lower their arms and relax.', answer: ans('てを おろして ください。 リラックスして ください。', 'Te o oroshite kudasai. Rirakkusu shite kudasai.', 'Lower your arms. Please relax.') },
      { cue: 'Class is over. Thank everyone for their hard work.', answer: ans('おつかれさまでした！', 'Otsukaresama deshita!', 'Great work, everyone!') },
    ],
  },

  {
    id: 'l9', n: 9, title: 'Counting and time', jp: 'かず と じかん',
    scene: 'You ask someone the time, chat about the weather, and talk about when your class starts.',
    dialogue: [
      A('すみません、 いま なんじですか。', 'Sumimasen, ima nanji desu ka?', 'Excuse me, what time is it?'),
      B('さんじです。', 'Sanji desu.', 'It’s three o’clock.'),
      A('ありがとうございます。 きょうは あついですね。', 'Arigatō gozaimasu. Kyō wa atsui desu ne.', 'Thank you. It’s hot today, isn’t it?'),
      B('そうですね。 でも、 あしたは さむいです。', 'Sō desu ne. Demo, ashita wa samui desu.', 'It is. But tomorrow will be cold.'),
      A('ほんとうですか。', 'Hontō desu ka?', 'Really?'),
      B('クラスは なんじからですか。', 'Kurasu wa nanji kara desu ka?', 'What time does your class start?'),
      A('ごじからです。', 'Goji kara desu.', 'At five.'),
    ],
    items: [
      p('count-1-4', 'いち、 に、 さん、 し', 'ichi, ni, san, shi', 'one, two, three, four', { intro: 'Dancers count in eights. Here are the first four counts: one, two, three, four.' }),
      p('count-5-8', 'ご、 ろく、 しち、 はち', 'go, roku, shichi, hachi', 'five, six, seven, eight'),
      w('nanji', 'なんじ', 'nanji', 'what time'),
      p('ima-nanji', 'いま なんじですか', 'ima nanji desu ka', 'What time is it now?'),
      w('sanji', 'さんじ', 'sanji', 'three o’clock', { intro: 'Add "ji" to a number to say o’clock. Three o’clock.' }),
      w('goji', 'ごじ', 'goji', 'five o’clock'),
      w('kyou', 'きょう', 'kyō', 'today'),
      w('ashita', 'あした', 'ashita', 'tomorrow'),
      w('atsui', 'あつい', 'atsui', 'hot, for weather'),
      w('samui', 'さむい', 'samui', 'cold, for weather'),
      p('kyou-atsui', 'きょうは あついですね', 'kyō wa atsui desu ne', 'It’s hot today, isn’t it?'),
      p('ashita-samui', 'あしたは さむいです', 'ashita wa samui desu', 'Tomorrow will be cold.'),
      w('hontou', 'ほんとうですか', 'hontō desu ka', 'really?'),
      w('kurasu', 'クラス', 'kurasu', 'class'),
      p('kurasu-nanji', 'クラスは なんじからですか', 'kurasu wa nanji kara desu ka', 'What time does class start?'),
      p('goji-kara', 'ごじからです', 'goji kara desu', 'From five o’clock.'),
    ],
    roleplay: [
      { cue: 'Start your dance class. Count the first four.', answer: ans('いち、 に、 さん、 し。', 'Ichi, ni, san, shi.', 'One, two, three, four.') },
      { cue: 'Now the next four.', answer: ans('ご、 ろく、 しち、 はち。', 'Go, roku, shichi, hachi.', 'Five, six, seven, eight.') },
      { cue: 'Ask someone what time it is now.', answer: ans('すみません、 いま なんじですか。', 'Sumimasen, ima nanji desu ka?', 'Excuse me, what time is it?') },
      { ask: B('いま なんじですか。', 'Ima nanji desu ka?', 'What time is it?'), cue: 'It’s three o’clock.', answer: ans('さんじです。', 'Sanji desu.', 'It’s three o’clock.') },
      { cue: 'Make small talk: It’s hot today, isn’t it?', answer: ans('きょうは あついですね。', 'Kyō wa atsui desu ne.', 'It’s hot today, isn’t it?') },
      { ask: B('あしたは さむいです。', 'Ashita wa samui desu.', 'Tomorrow will be cold.'), cue: 'Say "Really?"', answer: ans('ほんとうですか。', 'Hontō desu ka?', 'Really?') },
      { ask: B('クラスは なんじからですか。', 'Kurasu wa nanji kara desu ka?', 'What time does class start?'), cue: 'Your class starts at five.', answer: ans('ごじからです。', 'Goji kara desu.', 'From five.') },
    ],
  },

  {
    id: 'l10', n: 10, title: 'Let’s dance together', jp: 'いっしょに おどりませんか',
    scene: 'Yuki invites you to dance with her. You make plans and exchange contacts.',
    dialogue: [
      B('こんど いっしょに おどりませんか。', 'Kondo issho ni odorimasen ka?', 'Want to dance together sometime?'),
      A('いいですね！ ぜひ。', 'Ii desu ne! Zehi.', 'Sounds great! I’d love to.'),
      B('どようびは どうですか。', 'Doyōbi wa dō desu ka?', 'How about Saturday?'),
      A('すみません、 どようびは ちょっと…… にちようびは どうですか。', 'Sumimasen, doyōbi wa chotto... Nichiyōbi wa dō desu ka?', 'Sorry, Saturday is a bit... How about Sunday?'),
      B('だいじょうぶです。', 'Daijōbu desu.', 'That works.'),
      A('じゃあ、 ラインを こうかんしませんか。', 'Jā, rain o kōkan shimasen ka?', 'Then shall we exchange LINE?'),
      B('はい、 ぜひ。', 'Hai, zehi.', 'Yes, definitely.'),
      A('きょうは たのしかったです。 また あいましょう！', 'Kyō wa tanoshikatta desu. Mata aimashō!', 'Today was fun. Let’s meet again!'),
      B('じゃあ、 また！', 'Jā, mata!', 'See you!'),
    ],
    items: [
      w('kondo', 'こんど', 'kondo', 'sometime, or next time'),
      w('issho-ni', 'いっしょに', 'issho ni', 'together'),
      w('odorimasen-ka', 'おどりませんか', 'odorimasen ka', 'would you like to dance?', { intro: '"Masen ka" turns a verb into an invitation, like "won’t you?" Here is "Would you like to dance?"' }),
      p('issho-ni-odori', 'こんど いっしょに おどりませんか', 'kondo issho ni odorimasen ka', 'Want to dance together sometime?'),
      w('zehi', 'ぜひ', 'zehi', 'definitely, or I’d love to'),
      p('ii-desu-ne-zehi', 'いいですね、 ぜひ', 'ii desu ne, zehi', 'Sounds great, I’d love to.'),
      w('doyoubi', 'どようび', 'doyōbi', 'Saturday'),
      w('nichiyoubi', 'にちようび', 'nichiyōbi', 'Sunday'),
      w('dou-desu-ka', 'どうですか', 'dō desu ka', 'how about it?'),
      p('nichiyoubi-dou', 'にちようびは どうですか', 'nichiyōbi wa dō desu ka', 'How about Sunday?'),
      w('chotto', 'ちょっと', 'chotto', 'a little', { tip: 'Saying "chotto" and letting your voice trail off is the polite way to say no in Japanese.' }),
      p('doyoubi-chotto', 'どようびは ちょっと', 'doyōbi wa chotto...', 'Saturday is a little... difficult.'),
      p('rain-koukan', 'ラインを こうかんしませんか', 'rain o kōkan shimasen ka', 'Shall we exchange LINE contacts?', { tip: 'LINE is the messaging app everyone uses in Japan.' }),
      w('tanoshikatta', 'たのしかったです', 'tanoshikatta desu', 'it was fun'),
      p('kyou-tanoshikatta', 'きょうは たのしかったです', 'kyō wa tanoshikatta desu', 'Today was fun.'),
      p('mata-aimashou', 'また あいましょう', 'mata aimashō', 'Let’s meet again.'),
      p('jaa-mata', 'じゃあ、 また', 'jā, mata', 'See you!'),
    ],
    roleplay: [
      { cue: 'Invite Yuki to dance together sometime.', answer: ans('こんど いっしょに おどりませんか。', 'Kondo issho ni odorimasen ka?', 'Want to dance together sometime?') },
      { ask: B('こんど いっしょに おどりませんか。', 'Kondo issho ni odorimasen ka?', 'Want to dance together sometime?'), cue: 'Someone invites you. Say "Sounds great, I’d love to."', answer: ans('いいですね、 ぜひ。', 'Ii desu ne, zehi.', 'Sounds great, I’d love to.') },
      { ask: B('どようびは どうですか。', 'Doyōbi wa dō desu ka?', 'How about Saturday?'), cue: 'Saturday doesn’t work. Politely decline, then suggest Sunday.', answer: ans('どようびは ちょっと…… にちようびは どうですか。', 'Doyōbi wa chotto... Nichiyōbi wa dō desu ka?', 'Saturday is a bit... How about Sunday?') },
      { ask: B('だいじょうぶです。', 'Daijōbu desu.', 'That works.'), cue: 'Ask if she wants to exchange LINE.', answer: ans('じゃあ、 ラインを こうかんしませんか。', 'Jā, rain o kōkan shimasen ka?', 'Then shall we exchange LINE?') },
      { cue: 'Tell her today was fun.', answer: ans('きょうは たのしかったです。', 'Kyō wa tanoshikatta desu.', 'Today was fun.') },
      { cue: 'Say "Let’s meet again!" and "See you!"', answer: ans('また あいましょう！ じゃあ、 また！', 'Mata aimashō! Jā, mata!', 'Let’s meet again! See you!') },
    ],
  },
];

/** Every item, keyed by lesson-scoped id, so reviews can reach back. */
export function allItems(upToLesson = LESSONS.length): { lesson: Lesson; item: Item }[] {
  return LESSONS.slice(0, upToLesson).flatMap((lesson) => lesson.items.map((item) => ({ lesson, item })));
}

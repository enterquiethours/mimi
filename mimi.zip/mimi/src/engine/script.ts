// Turns lesson content into a timed audio script.
//
// The method:
//  1. Listen to a full conversation you can't understand yet.
//  2. Review earlier lessons (graduated: last lesson heavily, older ones lightly).
//  3. Learn each new word or phrase: hear it, then build it back up from the
//     END, sound by sound, repeating in the pauses.
//  4. Anticipation: the narrator asks "How do you say…?" and leaves a pause for
//     you to answer before you hear the correct version.
//  5. Graduated interval recall: each new item comes back a little later,
//     then later again, mixed in with new material.
//  6. Role-play: someone speaks to you, you answer in the pause, then hear
//     the model answer.

import { LESSONS, type Item, type Lesson, type Line, type Speaker } from '../content/lessons';
import { backchain, moraCount, speakable, toRomaji } from './kana';

export type Phase = 'listen' | 'repeat' | 'answer' | 'narrator';

export type Cue =
  | { kind: 'en'; text: string; phase: Phase; section: string; est: number }
  | { kind: 'ja'; text: string; say: string; ro: string; en?: string; who: Speaker; phase: Phase; section: string; est: number; slow?: boolean }
  | { kind: 'pause'; phase: Phase; section: string; est: number; ro?: string; ja?: string };

export type Script = { cues: Cue[]; totalSec: number; sections: { name: string; start: number }[] };

const TARGET_SEC = 28 * 60;

// --- duration estimates (seconds) -----------------------------------------
const jaSec = (kana: string, rate: number) => 0.35 + (moraCount(kana) * 0.14) / rate;
const enSec = (text: string) => 0.3 + text.split(/\s+/).length * 0.36;

// small deterministic RNG so a lesson sounds the same every time you play it
function rng(seed: number) {
  let s = seed || 1;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

class Builder {
  cues: Cue[] = [];
  section = 'Intro';
  sections: { name: string; start: number }[] = [];
  rand: () => number;
  constructor(public rate: number, seed: number) {
    this.rand = rng(seed);
  }
  pick<T>(xs: T[]): T {
    return xs[Math.floor(this.rand() * xs.length)];
  }
  begin(name: string) {
    this.section = name;
    this.sections.push({ name, start: this.cues.length });
  }
  en(text: string) {
    this.cues.push({ kind: 'en', text, phase: 'narrator', section: this.section, est: enSec(text) });
  }
  ja(line: { kana: string; ro?: string; en?: string; who?: Speaker }, phase: Phase = 'listen', slow = false) {
    const est = jaSec(line.kana, slow ? this.rate * 0.8 : this.rate);
    this.cues.push({
      kind: 'ja', text: line.kana, say: speakable(line.kana), ro: line.ro ?? toRomaji(line.kana), en: line.en,
      who: line.who ?? 'B', phase, section: this.section, est, slow,
    });
  }
  /** Pause long enough to repeat what you just heard. */
  repeatGap(kana: string, ro?: string) {
    const est = 1.2 + jaSec(kana, this.rate) * 1.5;
    this.cues.push({ kind: 'pause', phase: 'repeat', section: this.section, est, ja: kana, ro: ro ?? toRomaji(kana) });
  }
  /** Pause long enough to recall and say it yourself. */
  answerGap(kana: string, extra = 0) {
    const est = 2.6 + jaSec(kana, this.rate) * 1.6 + extra;
    this.cues.push({ kind: 'pause', phase: 'answer', section: this.section, est });
  }
  get total() {
    return this.cues.reduce((a, c) => a + c.est + 0.25, 0);
  }
}

const ASK = [
  (en: string) => `How do you say, "${en}"?`,
  (en: string) => `Say, "${en}".`,
  (en: string) => `Do you remember how to say, "${en}"?`,
  (en: string) => `Try saying, "${en}".`,
  (en: string) => `What’s "${en}"?`,
];

function teach(b: Builder, item: Item, firstLesson: boolean) {
  const voice: Line = { kana: item.kana, ro: item.ro, en: item.en, who: 'A' };
  b.en(item.intro ?? (item.kind === 'word' ? `Here’s how to say "${item.en}".` : `Now, "${item.en}".`));
  b.ja(voice);
  b.ja({ ...voice, who: 'B' }, 'listen', true);

  const steps = backchain(item.kana);
  if (steps.length > 1) {
    b.en(firstLesson && item.kind === 'word' ? 'Listen and repeat. We’ll start from the end of the word.' : b.pick(['Repeat after me, from the end.', 'Listen and repeat.', 'Build it from the end.']));
    for (const s of steps.slice(0, -1)) {
      b.ja({ kana: s, who: 'B' }, 'repeat', true);
      b.repeatGap(s);
    }
    b.en(item.kind === 'word' ? 'Now the whole word.' : 'Now all together.');
  } else {
    b.en('Listen and repeat.');
  }
  b.ja(voice, 'repeat');
  b.repeatGap(item.kana, item.ro);
  if (item.tip) b.en(item.tip);
  b.ja({ ...voice, who: 'B' }, 'repeat');
  b.repeatGap(item.kana, item.ro);
}

function recall(b: Builder, item: Item) {
  b.en(b.pick(ASK)(item.en));
  b.answerGap(item.kana);
  b.ja({ kana: item.kana, ro: item.ro, en: item.en, who: b.rand() > 0.5 ? 'A' : 'B' }, 'answer');
  b.repeatGap(item.kana, item.ro);
}

function playDialogue(b: Builder, lines: Line[]) {
  for (const l of lines) b.ja(l, 'listen');
}

/** Items from earlier lessons, weighted toward the most recent ones. */
function reviewPool(lesson: Lesson, b: Builder): Item[] {
  const plan: [back: number, count: number][] = [[1, 6], [2, 3], [3, 2], [5, 2], [8, 2]];
  const out: Item[] = [];
  for (const [back, count] of plan) {
    const src = LESSONS[lesson.n - 1 - back];
    if (!src) continue;
    // prefer phrases: they carry the most words
    const pool = [...src.items].sort((x, y) => (x.kind === y.kind ? b.rand() - 0.5 : x.kind === 'phrase' ? -1 : 1));
    out.push(...pool.slice(0, count));
  }
  return out;
}

export function buildLesson(lesson: Lesson, rate = 0.85): Script {
  const b = new Builder(rate, lesson.n * 7919);
  const first = lesson.n === 1;

  b.begin('Conversation');
  b.en(`Lesson ${lesson.n}. ${lesson.title}.`);
  if (first) {
    b.en('In this program you learn by listening and speaking. When you hear a pause, say the Japanese out loud. Don’t worry about mistakes. Just speak.');
  }
  b.en(lesson.scene);
  playDialogue(b, lesson.dialogue);
  b.en('In this lesson you’ll learn to understand that conversation, and to take part in it.');

  const review = reviewPool(lesson, b);
  if (review.length) {
    b.begin('Review');
    b.en('First, some review.');
    for (const it of review) recall(b, it);
  }

  // New material with graduated interval recall woven in.
  b.begin('New words');
  const queue: { item: Item; due: number }[] = [];
  const GAPS = [1, 3, 7];
  lesson.items.forEach((item, step) => {
    teach(b, item, first);
    GAPS.forEach((g) => queue.push({ item, due: step + g }));
    const due = queue.filter((q) => q.due <= step).sort((x, y) => x.due - y.due).slice(0, 2);
    for (const d of due) {
      queue.splice(queue.indexOf(d), 1);
      recall(b, d.item);
    }
  });
  for (const q of queue.sort((x, y) => x.due - y.due)) recall(b, q.item);

  // Mixed practice until the lesson is about 30 minutes.
  b.begin('Practice');
  b.en('Let’s practice everything together.');
  const mix = [...lesson.items, ...review];
  for (let round = 0; round < 4 && b.total < TARGET_SEC - 300; round++) {
    const order = [...mix].sort(() => b.rand() - 0.5);
    for (const it of order) {
      if (b.total >= TARGET_SEC - 300) break;
      recall(b, it);
    }
  }

  b.begin('Your turn');
  b.en('Now it’s your turn to have the conversation. Listen, then answer in the pause.');
  for (const r of lesson.roleplay) {
    if (r.ask) b.ja({ ...r.ask, who: 'B' }, 'listen');
    b.en(r.cue);
    b.answerGap(r.answer.kana, 1.5);
    b.ja({ ...r.answer, who: 'A' }, 'answer');
    b.repeatGap(r.answer.kana, r.answer.ro);
  }

  b.begin('Listen again');
  b.en('Listen to the conversation from the start of the lesson one more time. This time, you’ll understand it.');
  playDialogue(b, lesson.dialogue);
  const next = LESSONS[lesson.n];
  b.en(`This is the end of lesson ${lesson.n}. ${next ? `Tomorrow, go on to lesson ${next.n}. ` : ''}Great work.`);
  b.ja({ kana: 'おつかれさまでした', ro: 'otsukaresama deshita', en: 'great work', who: 'B' });

  return { cues: b.cues, totalSec: b.total, sections: b.sections };
}

/** A shorter, review-only session drawn from every lesson you've finished. */
export function buildReview(completedLessonIds: string[], rate = 0.85, minutes = 10): Script {
  const lessons = LESSONS.filter((l) => completedLessonIds.includes(l.id));
  const day = Math.floor(Date.now() / 86400000);
  const b = new Builder(rate, day);
  b.begin('Review');
  b.en('Quick review. Answer in the pause, then listen and repeat.');
  const items = lessons.flatMap((l) => l.items).sort(() => b.rand() - 0.5);
  for (const it of items) {
    if (b.total > minutes * 60) break;
    recall(b, it);
  }
  const roles = lessons.flatMap((l) => l.roleplay).sort(() => b.rand() - 0.5).slice(0, 4);
  if (roles.length) {
    b.begin('Your turn');
    b.en('Now some conversation.');
    for (const r of roles) {
      if (r.ask) b.ja({ ...r.ask, who: 'B' }, 'listen');
      b.en(r.cue);
      b.answerGap(r.answer.kana, 1.5);
      b.ja({ ...r.answer, who: 'A' }, 'answer');
      b.repeatGap(r.answer.kana, r.answer.ro);
    }
  }
  b.en('That’s the end of your review. Great work.');
  b.ja({ kana: 'おつかれさまでした', ro: 'otsukaresama deshita', en: 'great work', who: 'B' });
  return { cues: b.cues, totalSec: b.total, sections: b.sections };
}

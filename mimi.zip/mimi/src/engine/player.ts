import type { Cue, Script } from './script';
import * as tts from './tts';

export type PlayerState = {
  index: number;
  playing: boolean;
  done: boolean;
  /** Seconds elapsed in the current pause (for the countdown bar). */
  pauseStartedAt: number | null;
  pauseLength: number;
};

export type PlayerSettings = { rate: number; pauseScale: number };

const GAP_MS = 280;

export class LessonPlayer {
  private runId = 0;
  private timers: ReturnType<typeof setTimeout>[] = [];
  private listeners = new Set<(s: PlayerState) => void>();
  state: PlayerState;

  constructor(
    public script: Script,
    public settings: PlayerSettings,
    startAt = 0,
    private onFinish?: () => void,
  ) {
    this.state = { index: Math.min(startAt, script.cues.length - 1), playing: false, done: false, pauseStartedAt: null, pauseLength: 0 };
  }

  subscribe(fn: (s: PlayerState) => void) {
    this.listeners.add(fn);
    fn(this.state);
    return () => {
      this.listeners.delete(fn);
    };
  }

  private set(patch: Partial<PlayerState>) {
    this.state = { ...this.state, ...patch };
    this.listeners.forEach((l) => l(this.state));
  }

  get cue(): Cue | undefined {
    return this.script.cues[this.state.index];
  }

  private clear() {
    this.runId++;
    this.timers.forEach(clearTimeout);
    this.timers = [];
    tts.stop();
  }

  play() {
    if (this.state.playing) return;
    if (this.state.done) this.set({ index: 0, done: false });
    tts.unlock();
    this.set({ playing: true });
    this.run(this.state.index);
  }

  pause() {
    this.clear();
    this.set({ playing: false, pauseStartedAt: null });
  }

  toggle() {
    this.state.playing ? this.pause() : this.play();
  }

  /** Jump to a cue. Lands on spoken cues, never in the middle of a pause. */
  seek(i: number) {
    const cues = this.script.cues;
    let j = Math.max(0, Math.min(i, cues.length - 1));
    while (j > 0 && cues[j].kind === 'pause') j--;
    const wasPlaying = this.state.playing;
    this.clear();
    this.set({ index: j, done: false, pauseStartedAt: null });
    if (wasPlaying) {
      // give speechSynthesis a beat after cancel() — Chrome drops an immediate speak()
      this.timers.push(setTimeout(() => this.run(j), 120));
    }
  }

  /** Back to the start of the current exercise (the last narrator line). */
  back() {
    const cues = this.script.cues;
    let j = this.state.index - 1;
    while (j > 0 && cues[j].kind !== 'en') j--;
    this.seek(j);
  }

  /** Skip forward to the next exercise. */
  forward() {
    const cues = this.script.cues;
    let j = this.state.index + 1;
    while (j < cues.length - 1 && cues[j].kind !== 'en') j++;
    this.seek(j);
  }

  destroy() {
    this.clear();
    this.listeners.clear();
  }

  private run(i: number) {
    const id = ++this.runId;
    const cues = this.script.cues;
    if (i >= cues.length) {
      this.set({ playing: false, done: true, pauseStartedAt: null, index: cues.length - 1 });
      this.onFinish?.();
      return;
    }
    const cue = cues[i];
    const next = () => {
      if (id !== this.runId) return;
      this.timers.push(setTimeout(() => id === this.runId && this.run(i + 1), GAP_MS));
    };

    if (cue.kind === 'pause') {
      const ms = cue.est * this.settings.pauseScale * 1000;
      this.set({ index: i, pauseStartedAt: Date.now(), pauseLength: ms });
      this.timers.push(setTimeout(next, ms));
      return;
    }

    this.set({ index: i, pauseStartedAt: null });
    const text = cue.kind === 'en' ? cue.text : cue.say;
    const role = cue.kind === 'en' ? 'en' : cue.who;
    const rate = cue.kind === 'ja' && cue.slow ? this.settings.rate * 0.8 : this.settings.rate;
    // safety net: some browsers occasionally never fire `onend`
    const expected = cue.est * (this.settings.rate < 0.8 ? 1.4 : 1);
    this.timers.push(setTimeout(next, (expected * 2.5 + 4) * 1000));
    tts.speak(text, role, { rate, onDone: next });
  }
}

// Text-to-speech wrapper. On the web (the installable home-screen app) we talk
// to the browser's speechSynthesis directly so we can pick the best Japanese
// voices and start speaking synchronously inside a tap (required by iOS).
// On native iOS/Android we use expo-speech.

import { Platform } from 'react-native';
import * as Speech from 'expo-speech';
import type { Speaker } from '../content/lessons';

export type VoiceInfo = { id: string; name: string; lang: string; isDefault?: boolean };
type Role = 'en' | Speaker;

type Opts = { rate: number; onDone: () => void };

const isWeb = Platform.OS === 'web';
const synth: SpeechSynthesis | undefined = isWeb && typeof window !== 'undefined' ? window.speechSynthesis : undefined;

let chosen: Partial<Record<Role, VoiceInfo>> = {};
let webVoices: SpeechSynthesisVoice[] = [];
// keep a reference so Chrome doesn't garbage-collect the utterance mid-speech
let current: SpeechSynthesisUtterance | null = null;

// Apple ships joke voices that sound robotic; never pick them automatically.
const NOVELTY = /albert|bad news|bahh|bells|boing|bubbles|cellos|good news|jester|organ|superstar|trinoids|whisper|wobble|zarvox|fred|junior|ralph|kathy|grandma|grandpa|eddy|flo|reed|rocko|sandy|shelley/i;

function score(v: VoiceInfo, wantLang: string) {
  let s = 0;
  if (v.lang.replace('_', '-').toLowerCase().startsWith(wantLang)) s += 10;
  if (/natural|online|neural|premium|enhanced/i.test(v.name)) s += 5;
  if (v.isDefault) s += 3; // the voice chosen in the phone's settings
  if (/google/i.test(v.name)) s += 2;
  if (/kyoko|otoya|nanami|ava|zoe|evan|aria|jenny|maya/i.test(v.name)) s += 1;
  if (NOVELTY.test(v.name)) s -= 20;
  return s;
}

function rank(list: VoiceInfo[], lang: string) {
  return list
    .filter((v) => v.lang.replace('_', '-').toLowerCase().startsWith(lang))
    .sort((a, b) => score(b, lang) - score(a, lang));
}

export async function listVoices(): Promise<VoiceInfo[]> {
  if (synth) {
    const get = () => synth.getVoices();
    webVoices = get();
    if (!webVoices.length) {
      await new Promise<void>((resolve) => {
        const t = setTimeout(resolve, 2500);
        synth.addEventListener?.('voiceschanged', () => {
          clearTimeout(t);
          resolve();
        });
      });
      webVoices = get();
    }
    return webVoices.map((v) => ({ id: v.voiceURI, name: v.name, lang: v.lang, isDefault: v.default }));
  }
  try {
    const vs = await Speech.getAvailableVoicesAsync();
    return vs.map((v) => ({ id: v.identifier, name: v.name, lang: v.language }));
  } catch {
    return [];
  }
}

/** Pick voices. `prefs` lets the user override the Japanese voices. */
export async function initVoices(prefs?: { jaA?: string; jaB?: string; en?: string }) {
  const all = await listVoices();
  const ja = rank(all, 'ja');
  // all English voices (US, UK, Australian…), best guesses first
  const en = rank(all, 'en').sort((a, b) => score(b, 'en-us') - score(a, 'en-us'));
  const A = ja.find((v) => v.id === prefs?.jaA) ?? ja[0];
  const B = ja.find((v) => v.id === prefs?.jaB) ?? ja.find((v) => v !== A) ?? A;
  const E = en.find((v) => v.id === prefs?.en) ?? en[0];
  chosen = { A, B, en: E };
  return { ja, en, chosen, hasJapanese: ja.length > 0 };
}

export function voicesInfo() {
  return chosen;
}

/** Call from inside a tap: iOS only lets speech start from a user gesture. */
export function unlock() {
  if (!synth) return;
  try {
    synth.cancel();
    const u = new SpeechSynthesisUtterance(' ');
    u.volume = 0;
    synth.speak(u);
  } catch {}
}

/** Play a short sample in a specific voice (for the voice picker). */
export function preview(v: VoiceInfo, text: string) {
  stop();
  const saved = chosen;
  const role: Role = v.lang.toLowerCase().startsWith('ja') ? 'A' : 'en';
  chosen = { ...chosen, [role]: v, ...(role === 'A' ? { B: v } : {}) };
  speak(text, role, { rate: role === 'en' ? 1 : 0.85, onDone: () => {} });
  chosen = saved;
}

export function speak(text: string, role: Role, { rate, onDone }: Opts) {
  const lang = role === 'en' ? 'en-US' : 'ja-JP';
  const v = chosen[role];
  // one Japanese voice only? shift pitch so the two speakers sound different
  const sameVoice = role !== 'en' && chosen.A?.id === chosen.B?.id;
  const pitch = sameVoice ? (role === 'A' ? 1.1 : 0.85) : 1;
  const r = role === 'en' ? 1 : rate;

  if (synth) {
    const u = new SpeechSynthesisUtterance(text);
    u.lang = v?.lang ?? lang;
    const wv = webVoices.find((x) => x.voiceURI === v?.id);
    if (wv) u.voice = wv;
    u.rate = r;
    u.pitch = pitch;
    let fired = false;
    const done = () => {
      if (fired) return;
      fired = true;
      onDone();
    };
    u.onend = done;
    u.onerror = done;
    current = u;
    synth.speak(u);
    return;
  }

  Speech.speak(text, {
    language: lang,
    voice: v?.id,
    rate: r,
    pitch,
    onDone,
    onError: () => onDone(),
  });
}

export function stop() {
  current = null;
  if (synth) synth.cancel();
  else Speech.stop();
}

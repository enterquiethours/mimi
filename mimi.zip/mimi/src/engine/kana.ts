// Kana utilities: mora splitting (for syllable-by-syllable breakdowns)
// and Hepburn-style romaji for on-screen hints.

const SMALL = new Set(['ゃ', 'ゅ', 'ょ', 'ぁ', 'ぃ', 'ぅ', 'ぇ', 'ぉ', 'ゎ']);
// Characters that attach to the previous sound when we chunk for speech.
const ATTACH = new Set(['ん', 'ー', 'っ']);

export function toHiragana(s: string): string {
  return s.replace(/[ァ-ヶ]/g, (c) => String.fromCharCode(c.charCodeAt(0) - 0x60));
}

/** Split a single word into morae, e.g. すみません → す・み・ま・せん */
export function splitMorae(word: string): string[] {
  const out: string[] = [];
  for (const ch of word) {
    const h = toHiragana(ch);
    if (out.length && (SMALL.has(h) || ATTACH.has(h))) {
      out[out.length - 1] += ch;
    } else {
      out.push(ch);
    }
  }
  return out;
}

/**
 * Pimsleur-style backward build-up. Returns the pieces to repeat, ending
 * with the full item. Phrases (with spaces) build up word by word from the
 * end; single words build up sound by sound from the end.
 */
export function backchain(kana: string): string[] {
  const tokens = kana.split(/\s+/).filter(Boolean);
  if (tokens.length > 1) {
    const steps: string[] = [];
    for (let i = tokens.length - 1; i >= 0; i--) steps.push(tokens.slice(i).join(' '));
    return steps;
  }
  const m = splitMorae(tokens[0] ?? '');
  if (m.length <= 2) return [m.join('')];
  const steps: string[] = [];
  // last two sounds first, then add one sound at a time (two at a time for long words)
  const stride = m.length > 6 ? 2 : 1;
  for (let n = 2; n < m.length; n += stride) steps.push(m.slice(m.length - n).join(''));
  steps.push(m.join(''));
  return steps;
}

export function moraCount(kana: string): number {
  return kana
    .split(/\s+/)
    .filter(Boolean)
    .reduce((a, t) => a + splitMorae(t.replace(/[、。？！?!,.…]/g, '')).length, 0);
}

const BASE: Record<string, string> = {
  あ: 'a', い: 'i', う: 'u', え: 'e', お: 'o',
  か: 'ka', き: 'ki', く: 'ku', け: 'ke', こ: 'ko',
  が: 'ga', ぎ: 'gi', ぐ: 'gu', げ: 'ge', ご: 'go',
  さ: 'sa', し: 'shi', す: 'su', せ: 'se', そ: 'so',
  ざ: 'za', じ: 'ji', ず: 'zu', ぜ: 'ze', ぞ: 'zo',
  た: 'ta', ち: 'chi', つ: 'tsu', て: 'te', と: 'to',
  だ: 'da', ぢ: 'ji', づ: 'zu', で: 'de', ど: 'do',
  な: 'na', に: 'ni', ぬ: 'nu', ね: 'ne', の: 'no',
  は: 'ha', ひ: 'hi', ふ: 'fu', へ: 'he', ほ: 'ho',
  ば: 'ba', び: 'bi', ぶ: 'bu', べ: 'be', ぼ: 'bo',
  ぱ: 'pa', ぴ: 'pi', ぷ: 'pu', ぺ: 'pe', ぽ: 'po',
  ま: 'ma', み: 'mi', む: 'mu', め: 'me', も: 'mo',
  や: 'ya', ゆ: 'yu', よ: 'yo',
  ら: 'ra', り: 'ri', る: 'ru', れ: 're', ろ: 'ro',
  わ: 'wa', を: 'o', ん: 'n',
  ぁ: 'a', ぃ: 'i', ぅ: 'u', ぇ: 'e', ぉ: 'o', ゔ: 'vu',
};

const YOON: Record<string, string> = { ゃ: 'a', ゅ: 'u', ょ: 'o' };

function tokenToRomaji(token: string): string {
  const chars = [...toHiragana(token)];
  let out = '';
  for (let i = 0; i < chars.length; i++) {
    const c = chars[i];
    const next = chars[i + 1];
    if (c === 'っ') {
      const r = BASE[next ?? ''] ?? '';
      out += r.startsWith('ch') ? 't' : r[0] ?? '';
      continue;
    }
    if (c === 'ー') {
      const v = out.match(/[aeiou](?!.*[aeiou])/)?.[0] ?? '';
      out += v;
      continue;
    }
    let r = BASE[c];
    if (r === undefined) {
      out += c;
      continue;
    }
    if (next && YOON[next]) {
      // き + ゃ → kya, し + ゃ → sha, ち + ゃ → cha, じ + ゃ → ja
      if (r === 'shi' || r === 'chi' || r === 'ji') r = r.slice(0, -1) + YOON[next];
      else r = r.slice(0, -1) + 'y' + YOON[next];
      i++;
    } else if (next && 'ぁぃぅぇぉ'.includes(next)) {
      // loanword combos: ティ → ti, ファ → fa, ジェ → je, ウィ → wi
      const v = BASE[next];
      if (r === 'fu') r = 'f' + v;
      else if (r === 'u') r = 'w' + v;
      else if (r === 'shi' || r === 'chi' || r === 'ji') r = r.slice(0, -1) + v;
      else r = r.slice(0, -1) + v;
      i++;
    }
    if (r === 'n' && next && /^[aiueoy]/.test(BASE[next] ?? '')) r = "n'";
    out += r;
  }
  return out;
}

/** Romaji for a phrase. Particles は/へ at the end of a word read "wa"/"e". */
export function toRomaji(kana: string): string {
  return kana
    .split(/(\s+|[、。？！?!…])/)
    .map((tok) => {
      if (!tok || /^\s+$/.test(tok)) return tok;
      if (/^[、。？！?!…]$/.test(tok)) return ({ '、': ',', '。': '.', '？': '?', '！': '!', '…': '...' } as Record<string, string>)[tok] ?? tok;
      let t = tok;
      let tail = '';
      const h = toHiragana(t);
      if (h.length > 1 && h.endsWith('は')) {
        t = t.slice(0, -1);
        tail = /^(こんにち|こんばん)$/.test(h.slice(0, -1)) ? 'wa' : ' wa';
      } else if (h.length > 1 && h.endsWith('へ')) {
        t = t.slice(0, -1);
        tail = ' e';
      } else if (h.length > 1 && h.endsWith('を')) {
        t = t.slice(0, -1);
        tail = ' o';
      } else if (h.length > 2 && h.endsWith('で')) {
        t = t.slice(0, -1);
        tail = ' de';
      }
      return tokenToRomaji(t) + tail;
    })
    .join('')
    .replace(/\s+([,.?!])/g, '$1');
}

/** Text handed to the speech engine: no spaces (they make TTS pause oddly). */
export function speakable(kana: string): string {
  return kana.replace(/\s+/g, '').replace(/…+/g, '、');
}

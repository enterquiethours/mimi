import React from 'react';
import Svg, { Path, Circle } from 'react-native-svg';
import { C } from '../theme';

type P = { size?: number; color?: string };

export const Play = ({ size = 28, color = C.bg }: P) => (
  <Svg width={size} height={size} viewBox="0 0 24 24"><Path d="M8 5.5v13a1 1 0 0 0 1.5.86l10.5-6.5a1 1 0 0 0 0-1.72L9.5 4.64A1 1 0 0 0 8 5.5z" fill={color} /></Svg>
);
export const Pause = ({ size = 28, color = C.bg }: P) => (
  <Svg width={size} height={size} viewBox="0 0 24 24"><Path d="M7 5h3.5v14H7zM13.5 5H17v14h-3.5z" fill={color} /></Svg>
);
export const Back = ({ size = 26, color = C.text }: P) => (
  <Svg width={size} height={size} viewBox="0 0 24 24"><Path d="M12 5V2L7 6l5 4V7a6 6 0 1 1-6 6H4a8 8 0 1 0 8-8z" fill={color} /></Svg>
);
export const Forward = ({ size = 26, color = C.text }: P) => (
  <Svg width={size} height={size} viewBox="0 0 24 24"><Path d="M12 5V2l5 4-5 4V7a6 6 0 1 0 6 6h2a8 8 0 1 1-8-8z" fill={color} /></Svg>
);
export const Close = ({ size = 22, color = C.text }: P) => (
  <Svg width={size} height={size} viewBox="0 0 24 24"><Path d="M6 6l12 12M18 6L6 18" stroke={color} strokeWidth={2} strokeLinecap="round" /></Svg>
);
export const Check = ({ size = 16, color = C.bg }: P) => (
  <Svg width={size} height={size} viewBox="0 0 24 24"><Path d="M5 12.5l4.5 4.5L19 7.5" stroke={color} strokeWidth={2.6} fill="none" strokeLinecap="round" strokeLinejoin="round" /></Svg>
);
export const Flame = ({ size = 18, color = C.gold }: P) => (
  <Svg width={size} height={size} viewBox="0 0 24 24"><Path d="M12 2c1 4 5 6 5 11a5 5 0 0 1-10 0c0-2 1-3.5 2-4.5 0 2 1 3 2 3-1-4 1-7 1-9.5z" fill={color} /></Svg>
);
export const Text = ({ size = 22, color = C.text }: P) => (
  <Svg width={size} height={size} viewBox="0 0 24 24"><Path d="M4 19L9.5 5h1L16 19M6.2 14h7.6M17 19v-7m0 0a2.5 2.5 0 1 1 0 5" stroke={color} strokeWidth={1.8} fill="none" strokeLinecap="round" /></Svg>
);
export const Dot = ({ size = 8, color = C.accent }: P) => (
  <Svg width={size} height={size}><Circle cx={size / 2} cy={size / 2} r={size / 2} fill={color} /></Svg>
);

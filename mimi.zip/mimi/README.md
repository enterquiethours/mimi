# mimi · Japanese by ear

An audio-first Japanese course built with Expo. Each lesson is about 30 minutes,
and you mostly just listen and speak:

1. **Conversation** – hear a full exchange you can't understand yet.
2. **Review** – recall phrases from earlier lessons (yesterday's most, older ones less).
3. **New words** – each word is built back up from the *end*, sound by sound
   (ません → みません → すみません), with pauses to repeat.
4. **Anticipation** – "How do you say…?", a pause to answer out loud, then the right answer.
5. **Graduated recall** – new items come back after 1, 3 and 7 exercises.
6. **Your turn** – someone speaks to you; you answer in the pause, then hear the model answer.
7. **Listen again** – the opening conversation, which you now understand.

Voices come from the device's built-in text-to-speech, so there are no audio files
and it works offline once installed.

## Lessons

| # | Topic |
|---|---|
| 1 | First words: excuse me, I don't understand, a little Japanese |
| 2 | Nice to meet you: name, American, from New York |
| 3 | Where is it? station, restroom, left/right, "once more, slowly" |
| 4 | At the grocery store: do you have…, how much, bag, card |
| 5 | At the café: ordering, iced/hot, delicious, the check |
| 6 | I love to dance: hobbies, dancing since age five, jazz & ballet |
| 7 | What I do: stretch teacher at the YMCA, worked at the UN |
| 8 | Teaching a stretch class: breathe in/out, raise arms, relax |
| 9 | Counting and time: dance counts 1–8, o'clock, today/tomorrow, weather |
| 10 | Let's dance together: invitations, days, exchanging LINE |

**Flashcards:** every word and phrase from the lessons you have finished, Japanese → English or English → Japanese, with audio. Cards you miss come back sooner (spaced repetition).

Add lessons in `src/content/lessons.ts`. The engine (`src/engine/script.ts`)
turns each lesson into the audio script automatically, so new content only needs
the dialogue, the words/phrases in teaching order, and the role-play prompts.

## Run it

```bash
npm install
npx expo start          # press i for the iOS simulator, w for the browser
```

## Put it on your phone's home screen (GitHub Pages)

1. Create a GitHub repo (e.g. `mimi`) and push this folder to the `main` branch.
2. In the repo: **Settings → Pages → Source: GitHub Actions**.
3. The included workflow builds and deploys on every push. Your app will be at
   `https://<your-username>.github.io/mimi/`.
4. On iPhone, open that link in **Safari → Share → Add to Home Screen**.

**Japanese voice on iPhone:** Settings → Accessibility → Spoken Content → Voices →
Japanese → download *Kyoko* or *Otoya* (the Enhanced versions sound best).
Keep the app open while you listen; iOS pauses web speech when the screen locks.

Progress (streak, minutes per day, finished lessons, where you left off) is
saved on the device.
